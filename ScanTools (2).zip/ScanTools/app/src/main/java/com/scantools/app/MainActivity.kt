package com.scantools.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.scantools.app.ui.HomeScreen
import com.scantools.app.ui.ScanScreen
import com.scantools.app.ui.Specs

private val Scheme = darkColorScheme(
    primary = Color(0xFFCFBCFF),
    onPrimary = Color(0xFF381E72),
    primaryContainer = Color(0xFF4F378B),
    secondaryContainer = Color(0xFF4A4458),
    background = Color(0xFF141218),
    surface = Color(0xFF141218),
    surfaceContainerHigh = Color(0xFF2B2930),
    onBackground = Color(0xFFE6E0E9),
    onSurface = Color(0xFFE6E0E9),
    onSurfaceVariant = Color(0xFFCAC4D0),
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = Scheme) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { App() }
            }
        }
    }
}

@Composable
private fun App() {
    var current by rememberSaveable { mutableStateOf<String?>(null) }
    val spec = current?.let { id -> Specs.all.firstOrNull { it.id == id } }
    if (spec == null) {
        HomeScreen { current = it }
    } else {
        BackHandler { current = null }
        ScanScreen(spec) { current = null }
    }
}
