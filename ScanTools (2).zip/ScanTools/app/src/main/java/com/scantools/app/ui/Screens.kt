package com.scantools.app.ui

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.scantools.app.scan.ProbeResult

@Composable
fun HomeScreen(onOpen: (String) -> Unit) {
    Scaffold { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(vertical = 12.dp)) {
            item {
                Text(
                    "Scans",
                    style = MaterialTheme.typography.headlineMedium,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp),
                )
            }
            items(Specs.all, key = { it.id }) { s ->
                ListItem(
                    headlineContent = { Text(s.title, style = MaterialTheme.typography.titleMedium) },
                    supportingContent = { Text(s.subtitle) },
                    leadingContent = {
                        Icon(s.icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
                    },
                    colors = ListItemDefaults.colors(containerColor = MaterialTheme.colorScheme.background),
                    modifier = Modifier.clickable { onOpen(s.id) }.padding(vertical = 6.dp),
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScanScreen(spec: ScanSpec, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val vm: ScanViewModel = viewModel(key = spec.id)
    var variant by rememberSaveable(spec.id) { mutableStateOf(Prefs.lastVariant(ctx, spec)) }
    val values = remember(spec.id, variant) {
        mutableStateMapOf<String, String>().apply { putAll(Prefs.load(ctx, spec, variant)) }
    }
    var showInputs by rememberSaveable(spec.id) { mutableStateOf(!vm.running && vm.results.isEmpty()) }
    var onlyOk by rememberSaveable(spec.id) { mutableStateOf(true) }
    val clipboard = LocalClipboardManager.current

    val shown by remember(spec.id) {
        derivedStateOf {
            vm.results.asSequence()
                .filter { !onlyOk || it.ok }
                .sortedWith(compareBy<ProbeResult>({ !it.ok }, { it.latencyMs }))
                .take(500)
                .toList()
        }
    }

    fun workingText(): String =
        vm.results.filter { it.ok }.sortedBy { it.latencyMs }.joinToString("\n") { it.target }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(spec.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
                },
                actions = {
                    IconButton(onClick = {
                        Prefs.reset(ctx, spec, variant)
                        values.clear()
                        values.putAll(Prefs.load(ctx, spec, variant))
                        Toast.makeText(ctx, "Settings reset to defaults", Toast.LENGTH_SHORT).show()
                    }) { Icon(Icons.Filled.Refresh, contentDescription = "Reset settings") }
                },
            )
        },
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                Text(spec.subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (spec.variants.isNotEmpty()) {
                item {
                    ChipRow(spec.variants.map { it.name }, setOf(variant)) {
                        if (!vm.running) {
                            Prefs.save(ctx, spec, variant, values)
                            variant = it
                            Prefs.saveVariant(ctx, spec, it)
                        }
                    }
                }
            }
            item {
                TextButton(onClick = { showInputs = !showInputs }) {
                    Text(if (showInputs) "▲ Hide settings" else "▼ Show settings")
                }
            }
            if (showInputs) {
                items(spec.fields, key = { "f-" + it.key }) { f ->
                    FieldEditor(f, values[f.key] ?: f.default) { values[f.key] = it }
                }
            }
            item {
                Button(
                    onClick = {
                        if (vm.running) vm.stop() else {
                            Prefs.save(ctx, spec, variant, values)
                            showInputs = false
                            vm.start(spec, values.toMap())
                        }
                    },
                    colors = if (vm.running) ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    else ButtonDefaults.buttonColors(),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Icon(if (vm.running) Icons.Filled.Close else Icons.Filled.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (vm.running) "Stop" else "Start scan")
                }
            }
            if (vm.status.isNotEmpty()) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(vm.status, style = MaterialTheme.typography.bodyMedium)
                        if (vm.total > 0) {
                            LinearProgressIndicator(
                                progress = { if (vm.total == 0) 0f else vm.done.toFloat() / vm.total },
                                modifier = Modifier.fillMaxWidth(),
                            )
                            Text(
                                "${vm.done}/${vm.total} tested · ${vm.okCount} working",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
            if (vm.results.isNotEmpty()) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        FilterChip(selected = onlyOk, onClick = { onlyOk = !onlyOk }, label = { Text("Only working") })
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = {
                            val t = workingText()
                            if (t.isEmpty()) Toast.makeText(ctx, "Nothing working yet", Toast.LENGTH_SHORT).show()
                            else {
                                clipboard.setText(AnnotatedString(t))
                                Toast.makeText(ctx, "Copied ${t.lines().size} results", Toast.LENGTH_SHORT).show()
                            }
                        }) { Text("Copy") }
                        TextButton(onClick = {
                            val t = workingText()
                            if (t.isNotEmpty()) {
                                val i = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, t)
                                }
                                ctx.startActivity(Intent.createChooser(i, "Share results"))
                            }
                        }) { Text("Share") }
                    }
                }
                items(shown) { r ->
                    ResultCard(r) {
                        clipboard.setText(AnnotatedString(r.target.substringBefore(" @ ")))
                        Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
                    }
                }
                if (shown.size >= 500) {
                    item {
                        Text("Showing best 500 — use Copy/Share for the full list.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChipRow(options: List<String>, selected: Set<String>, onClick: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { o ->
            FilterChip(selected = o in selected, onClick = { onClick(o) }, label = { Text(o) })
        }
    }
}

@Composable
private fun FieldEditor(f: Field, value: String, onChange: (String) -> Unit) {
    when (f.kind) {
        Kind.CHOICE -> Column {
            Text(f.label, style = MaterialTheme.typography.labelLarge)
            ChipRow(f.options, setOf(value)) { onChange(it) }
        }
        Kind.MULTICHOICE -> {
            val set = value.split(',').map { it.trim() }.filter { it.isNotEmpty() }.toSet()
            Column {
                Text(f.label, style = MaterialTheme.typography.labelLarge)
                ChipRow(f.options, set) { o ->
                    val next = if (o in set) set - o else set + o
                    onChange(f.options.filter { it in next }.joinToString(","))
                }
            }
        }
        else -> {
            val multi = f.kind == Kind.MULTI
            OutlinedTextField(
                value = value,
                onValueChange = onChange,
                label = { Text(f.label) },
                placeholder = { if (f.hint.isNotEmpty()) Text(f.hint) },
                singleLine = !multi,
                minLines = if (multi) 3 else 1,
                maxLines = if (multi) 8 else 1,
                keyboardOptions = if (f.kind == Kind.NUMBER) KeyboardOptions(keyboardType = KeyboardType.Number) else KeyboardOptions.Default,
                textStyle = if (multi) LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                else LocalTextStyle.current,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

@Composable
private fun ResultCard(r: ProbeResult, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    r.target,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    if (r.ok) "${r.latencyMs} ms" else "✗",
                    color = if (r.ok) latencyColor(r.latencyMs) else MaterialTheme.colorScheme.error,
                    fontWeight = FontWeight.Bold,
                )
            }
            Text(r.detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun latencyColor(ms: Long): Color = when {
    ms < 300 -> Color(0xFF7BD88F)
    ms < 800 -> Color(0xFFF2C14E)
    else -> Color(0xFFFF8A80)
}
