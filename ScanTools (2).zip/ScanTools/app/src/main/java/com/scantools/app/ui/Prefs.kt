package com.scantools.app.ui

import android.content.Context

/** Remembers every field per scan (and per CDN for the Edge finder). */
object Prefs {
    private fun sp(ctx: Context) = ctx.getSharedPreferences("scantools", Context.MODE_PRIVATE)

    fun lastVariant(ctx: Context, spec: ScanSpec): String {
        val first = spec.variants.firstOrNull()?.name ?: return ""
        return sp(ctx).getString("${spec.id}:variant", first) ?: first
    }

    fun saveVariant(ctx: Context, spec: ScanSpec, variant: String) {
        sp(ctx).edit().putString("${spec.id}:variant", variant).apply()
    }

    fun load(ctx: Context, spec: ScanSpec, variant: String): Map<String, String> {
        val defaults = spec.variants.firstOrNull { it.name == variant }?.defaults ?: emptyMap()
        val p = sp(ctx)
        return spec.fields.associate { f ->
            f.key to (p.getString("${spec.id}:$variant:${f.key}", null) ?: defaults[f.key] ?: f.default)
        }
    }

    fun save(ctx: Context, spec: ScanSpec, variant: String, values: Map<String, String>) {
        val e = sp(ctx).edit()
        values.forEach { (k, v) -> e.putString("${spec.id}:$variant:$k", v) }
        e.apply()
    }

    fun reset(ctx: Context, spec: ScanSpec, variant: String) {
        val e = sp(ctx).edit()
        spec.fields.forEach { e.remove("${spec.id}:$variant:${it.key}") }
        e.apply()
    }
}
