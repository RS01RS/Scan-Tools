package com.scantools.app.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.ui.graphics.vector.ImageVector
import com.scantools.app.scan.EdgeCfg
import com.scantools.app.scan.ProbeResult
import com.scantools.app.scan.Probes
import com.scantools.app.scan.Targets

enum class Kind { TEXT, MULTI, NUMBER, CHOICE, MULTICHOICE }

data class Field(
    val key: String,
    val label: String,
    val default: String = "",
    val kind: Kind = Kind.TEXT,
    val options: List<String> = emptyList(),
    val hint: String = "",
)

data class Variant(val name: String, val defaults: Map<String, String>)

class ScanSpec(
    val id: String,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val fields: List<Field>,
    val variants: List<Variant> = emptyList(),
    val prepare: (Map<String, String>) -> List<String>,
    val probe: (String, Map<String, String>) -> ProbeResult,
)

private fun Map<String, String>.int(k: String, d: Int) = this[k]?.trim()?.toIntOrNull() ?: d
private fun Map<String, String>.str(k: String) = this[k]?.trim().orEmpty()

private fun common(conc: String, timeout: String) = listOf(
    Field("concurrency", "Concurrency (parallel tests)", conc, Kind.NUMBER),
    Field("timeout", "Timeout (ms)", timeout, Kind.NUMBER),
)

private fun edgeCfg(v: Map<String, String>) = EdgeCfg(
    port = v.int("port", 443),
    tls = v["tls"] != "off",
    sni = v.str("sni"),
    hostHeader = v.str("host"),
    path = v.str("path"),
    expect = v.str("expect"),
    marker = v.str("marker"),
    timeout = v.int("timeout", 2000),
    downloadKb = v.int("download", 0),
)

object Specs {
    val CLOUDFLARE = """
        173.245.48.0/20
        103.21.244.0/22
        103.22.200.0/22
        103.31.4.0/22
        141.101.64.0/18
        108.162.192.0/18
        190.93.240.0/20
        188.114.96.0/20
        197.234.240.0/22
        198.41.128.0/17
        162.158.0.0/15
        104.16.0.0/13
        104.24.0.0/14
        172.64.0.0/13
        131.0.72.0/22
    """.trimIndent()

    val FASTLY = """
        23.235.32.0/20
        43.249.72.0/22
        103.244.50.0/24
        103.245.222.0/23
        103.245.224.0/24
        104.156.80.0/20
        140.248.64.0/18
        140.248.128.0/17
        146.75.0.0/17
        151.101.0.0/16
        157.52.64.0/18
        167.82.0.0/17
        172.111.64.0/18
        185.31.16.0/22
        199.27.72.0/21
        199.232.0.0/16
    """.trimIndent()

    val CLOUDFRONT = """
        13.32.0.0/15
        13.224.0.0/14
        18.64.0.0/14
        52.84.0.0/15
        54.182.0.0/16
        54.192.0.0/16
        54.230.0.0/16
        54.239.128.0/18
        99.84.0.0/16
        205.251.192.0/19
    """.trimIndent()

    private val edgeFields = listOf(
        Field("targets", "IPs / CIDR ranges / domains", "", Kind.MULTI, hint = "one per line, e.g. 104.16.0.0/13"),
        Field("perCidr", "IPs to test per range", "20", Kind.NUMBER),
        Field("port", "Port", "443", Kind.NUMBER),
        Field("tls", "TLS", "on", Kind.CHOICE, listOf("on", "off")),
        Field("sni", "SNI (TLS server name)", ""),
        Field("host", "Host header (empty = same as SNI)", ""),
        Field("path", "Path", "/"),
        Field("expect", "Expected HTTP status", "any", hint = "any, 200, 2xx,3xx …"),
        Field("marker", "Response must contain (optional)", ""),
    ) + common("50", "2000")

    val cfScan = ScanSpec(
        id = "cf", title = "Scan IPs",
        subtitle = "Cloudflare clean IP finder — your IPs, CIDRs or edge domains",
        icon = Icons.Filled.Search,
        fields = listOf(
            Field("targets", "IPs / CIDR ranges / domains", CLOUDFLARE, Kind.MULTI),
            Field("perCidr", "IPs to test per range", "20", Kind.NUMBER),
            Field("port", "Port", "443", Kind.NUMBER, hint = "443, 2053, 2083, 2087, 2096, 8443 · or 80, 8080 with TLS off"),
            Field("tls", "TLS", "on", Kind.CHOICE, listOf("on", "off")),
            Field("sni", "SNI / Host", "speed.cloudflare.com"),
            Field("download", "Download test size KB (0 = off)", "0", Kind.NUMBER, hint = "works with speed.cloudflare.com"),
        ) + common("50", "2000"),
        prepare = { v -> Targets.expandIps(v["targets"], v.int("perCidr", 20)) },
        probe = { ip, v ->
            Probes.edge(ip, edgeCfg(v).copy(hostHeader = "", path = "/cdn-cgi/trace", expect = "200", marker = "colo="))
        },
    )

    val edge = ScanSpec(
        id = "edge", title = "Edge Provider IP Finder",
        subtitle = "Choose a CDN and keep its own targets and options",
        icon = Icons.Filled.Place,
        fields = edgeFields,
        variants = listOf(
            Variant("Cloudflare", mapOf("targets" to CLOUDFLARE, "sni" to "speed.cloudflare.com", "path" to "/cdn-cgi/trace", "expect" to "200", "marker" to "colo=")),
            Variant("Fastly", mapOf("targets" to FASTLY, "sni" to "www.python.org", "path" to "/", "expect" to "any", "marker" to "varnish")),
            Variant("CloudFront", mapOf("targets" to CLOUDFRONT, "sni" to "d1.awsstatic.com", "path" to "/", "expect" to "any", "marker" to "cloudfront")),
            Variant("Custom", mapOf("targets" to "", "sni" to "", "path" to "/", "expect" to "any", "marker" to "")),
        ),
        prepare = { v -> Targets.expandIps(v["targets"], v.int("perCidr", 20)) },
        probe = { ip, v -> Probes.edge(ip, edgeCfg(v)) },
    )

    val http = ScanSpec(
        id = "http", title = "Scan HTTP Proxies",
        subtitle = "Verify forwarding through your proxy endpoints",
        icon = Icons.AutoMirrored.Filled.Send,
        fields = listOf(
            Field("targets", "Proxies", "", Kind.MULTI, hint = "host:port · user:pass@host:port · host:port:user:pass"),
            Field("mode", "Mode", "GET", Kind.CHOICE, listOf("GET", "CONNECT")),
            Field("url", "Test URL", "http://cp.cloudflare.com/generate_204"),
            Field("expect", "Expected HTTP status", "204"),
        ) + common("30", "5000"),
        prepare = { v -> Targets.tokens(v["targets"]).distinct() },
        probe = { t, v -> Probes.httpProxy(t, v.str("mode"), v.str("url"), v.str("expect"), v.int("timeout", 5000)) },
    )

    val socks = ScanSpec(
        id = "socks", title = "Scan SOCKS5 Proxies",
        subtitle = "Verify SOCKS5 proxy forwarding",
        icon = Icons.Filled.Share,
        fields = listOf(
            Field("targets", "Proxies", "", Kind.MULTI, hint = "host:port · socks5://user:pass@host:port"),
            Field("url", "Test URL", "http://cp.cloudflare.com/generate_204"),
            Field("expect", "Expected HTTP status", "204"),
        ) + common("30", "5000"),
        prepare = { v -> Targets.tokens(v["targets"]).distinct() },
        probe = { t, v -> Probes.socks5(t, v.str("url"), v.str("expect"), v.int("timeout", 5000)) },
    )

    val sni = ScanSpec(
        id = "sni", title = "SNI Scanner (TLS Hostname Probe)",
        subtitle = "Dedicated hostname/certificate checks; separate from IP/proxy scans",
        icon = Icons.Filled.Lock,
        fields = listOf(
            Field("ips", "Target IPs / ranges / domains", "", Kind.MULTI, hint = "e.g. a clean Cloudflare IP"),
            Field("perCidr", "IPs to test per range", "5", Kind.NUMBER),
            Field(
                "snis", "Hostnames (SNI) to try",
                "speed.cloudflare.com\nwww.cloudflare.com\ndiscord.com\nwww.speedtest.net\nchatgpt.com\nwww.zula.ir",
                Kind.MULTI,
            ),
            Field("port", "Port", "443", Kind.NUMBER),
            Field("http", "HTTP check after handshake", "off", Kind.CHOICE, listOf("off", "on")),
        ) + common("20", "3000"),
        prepare = { v ->
            val ips = Targets.expandIps(v["ips"], v.int("perCidr", 5))
            val names = Targets.tokens(v["snis"]).distinct()
            ips.flatMap { ip -> names.map { "$ip|$it" } }.take(Targets.HARD_LIMIT)
        },
        probe = { t, v -> Probes.sni(t, v.int("port", 443), v["http"] == "on", v.int("timeout", 3000)) },
    )

    val dns = ScanSpec(
        id = "dns", title = "DNS Resolver / Tunnel Scan",
        subtitle = "UDP, TCP, DoT, DoH and tunnel readiness",
        icon = Icons.AutoMirrored.Filled.List,
        fields = listOf(
            Field(
                "targets", "Resolvers (IPs, ranges or DoH URLs)",
                "1.1.1.1\n8.8.8.8\n9.9.9.9\n208.67.222.222\n178.22.122.100\n185.51.200.2\nhttps://cloudflare-dns.com/dns-query",
                Kind.MULTI,
            ),
            Field("perCidr", "IPs to test per range", "20", Kind.NUMBER),
            Field("domain", "Test domain", "google.com"),
            Field("modes", "Protocols", "UDP,TCP,DoT,DoH", Kind.MULTICHOICE, listOf("UDP", "TCP", "DoT", "DoH")),
            Field("dohPath", "DoH path", "/dns-query"),
            Field("tlsName", "DoT/DoH SNI (optional)", ""),
            Field("tunnel", "Tunnel domain (optional)", "", hint = "e.g. t.example.com for dnstt / slipstream"),
        ) + common("30", "3000"),
        prepare = { v ->
            val per = v.int("perCidr", 20)
            Targets.tokens(v["targets"]).flatMap {
                if (it.startsWith("https://", true)) listOf(it) else Targets.expandIps(it, per)
            }.distinct()
        },
        probe = { t, v ->
            Probes.dns(
                t,
                Probes.DnsCfg(
                    domain = v.str("domain").ifEmpty { "google.com" },
                    modes = v.str("modes").split(',').map { it.trim() }.toSet(),
                    dohPath = v.str("dohPath").ifEmpty { "/dns-query" },
                    tlsName = v.str("tlsName"),
                    tunnelDomain = v.str("tunnel"),
                    timeout = v.int("timeout", 3000),
                ),
            )
        },
    )

    val all = listOf(cfScan, edge, http, socks, sni, dns)
}
