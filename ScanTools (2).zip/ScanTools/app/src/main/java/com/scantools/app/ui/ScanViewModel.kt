package com.scantools.app.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.scantools.app.scan.ProbeResult
import com.scantools.app.scan.err
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Runs one scan at a time; lives in the activity so a scan keeps going when you go back to the menu. */
class ScanViewModel : ViewModel() {
    val results = mutableStateListOf<ProbeResult>()
    var running by mutableStateOf(false)
        private set
    var done by mutableIntStateOf(0)
        private set
    var total by mutableIntStateOf(0)
        private set
    var okCount by mutableIntStateOf(0)
        private set
    var status by mutableStateOf("")
        private set
    private var job: Job? = null

    @OptIn(ExperimentalCoroutinesApi::class)
    fun start(spec: ScanSpec, values: Map<String, String>) {
        if (running) return
        results.clear(); done = 0; total = 0; okCount = 0
        status = "Preparing targets…"
        running = true
        job = viewModelScope.launch {
            try {
                val targets = withContext(Dispatchers.IO) { spec.prepare(values) }
                total = targets.size
                if (targets.isEmpty()) {
                    status = "No targets — check your input"
                    return@launch
                }
                status = "Scanning ${targets.size} targets…"
                val conc = (values["concurrency"]?.trim()?.toIntOrNull() ?: 32).coerceIn(1, 512)
                val disp = Dispatchers.IO.limitedParallelism(conc)
                val queue = Channel<String>(Channel.UNLIMITED)
                targets.forEach { queue.trySend(it) }
                queue.close()
                val out = Channel<ProbeResult>(Channel.UNLIMITED)
                val workers = List(minOf(conc, targets.size)) {
                    launch(disp) {
                        for (t in queue) {
                            val r = try { spec.probe(t, values) } catch (e: Exception) { ProbeResult(t, false, 0, err(e)) }
                            out.send(r)
                        }
                    }
                }
                launch { workers.joinAll(); out.close() }
                for (r in out) {
                    done++
                    if (r.ok) okCount++
                    results.add(r)
                }
                status = "Done — $okCount working out of $total"
            } catch (e: CancellationException) {
                status = "Stopped — $okCount working out of $done tested"
                throw e
            } catch (e: Exception) {
                status = "Error: ${err(e)}"
            } finally {
                running = false
            }
        }
    }

    fun stop() { job?.cancel() }
}
