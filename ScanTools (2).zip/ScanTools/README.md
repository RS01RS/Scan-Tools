# Scan Tools (Android)

اسکنر شبکه با ۶ بخش: Scan IPs (پیدا کردن IP تمیز کلودفلر)، Edge Provider IP Finder (Cloudflare / Fastly / CloudFront / Custom)، اسکن پروکسی HTTP، اسکن SOCKS5، SNI Scanner و DNS Resolver / Tunnel Scan.

## ساخت APK بدون کامپیوتر (GitHub Actions)
1. در github.com یک ریپازیتوری جدید بسازید (Private هم مشکلی ندارد).
2. Add file ← Upload files را بزنید و **محتوای** پوشه ScanTools را آپلود کنید (پوشه‌های app، gradle، .github و فایل‌های کنار آن‌ها). پوشه `.github` حتماً باید آپلود شود.
3. به تب Actions بروید. اجرای «Build APK» حدود ۵ دقیقه طول می‌کشد.
4. بعد از تمام شدن، روی همان اجرا بزنید و از بخش Artifacts فایل `ScanTools-apk` را دانلود کنید. فایل zip را باز کنید و APK را نصب کنید.

## ساخت با Android Studio
پوشه را با Open باز کنید، صبر کنید Gradle Sync تمام شود، بعد Build ← Build APK(s).

## نکته‌ها
- تنظیمات هر بخش (و هر CDN در Edge Finder) ذخیره می‌شود. دکمه ⟳ بالای صفحه تنظیمات را به حالت پیش‌فرض برمی‌گرداند.
- اگر از صفحه اسکن به منوی اصلی برگردید، اسکن متوقف نمی‌شود و ادامه پیدا می‌کند.
- با زدن روی هر نتیجه، آن مورد کپی می‌شود. دکمه Copy همه موارد سالم را به ترتیب پینگ کپی می‌کند.
- فرمت پروکسی‌ها: `host:port` یا `user:pass@host:port` یا `host:port:user:pass` یا `socks5://...`
- تست تونل DNS: دامنه تونل خود را وارد کنید (مثلاً `t.example.com`). یک کوئری TXT برای یک زیردامنه تصادفی آن فرستاده می‌شود. اگر resolver جواب بدهد و جواب SERVFAIL یا REFUSED نباشد، آن resolver برای dnstt یا slipstream مناسب است.
