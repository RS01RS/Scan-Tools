# Scan Tools — Made by (R.S)

شش ابزار اسکن شبکه با همان تم، منو، وضعیت اینترنت و بروزرسانی VPN Scan:
Scan IPs (IP تمیز کلودفلر) · Edge Provider IP Finder (Cloudflare / Fastly / CloudFront / Custom) · HTTP Proxies · SOCKS5 Proxies · SNI Scanner · DNS Resolver / Tunnel Scan

- رابط: `app/src/main/assets/index.html` · پل اندروید: `MainActivity.kt` · موتور اسکن: `scan/`
- هر بار که `ScanTools.zip` در مخزن عوض شود، Actions برنامه را می‌سازد و `Scan-Tools.apk` را در Releases منتشر می‌کند.
- بروزرسانی داخل برنامه از Releases مخزن `RS01RS/Scan-Tools` خوانده می‌شود.
- امضا با همان کلید `rs-key.jks` (مثل VPN Scan)، تا نسخه‌های بعدی روی قبلی نصب شوند.
