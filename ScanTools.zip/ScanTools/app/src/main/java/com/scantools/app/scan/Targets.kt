package com.scantools.app.scan

import java.math.BigInteger
import java.net.InetAddress
import java.util.Random

/** Parsing of user input: IPs, CIDR ranges (v4 + v6), domains and proxy endpoints. */
object Targets {
    const val HARD_LIMIT = 100_000
    private val rnd = Random()
    private val IPV4 = Regex("""^\d{1,3}(\.\d{1,3}){3}$""")

    /** Splits text into tokens. Lines may contain several entries; text after '#' is a comment. */
    fun tokens(input: String?): List<String> = (input ?: "").lineSequence()
        .map { it.substringBefore('#') }
        .flatMap { it.split(',', ' ', '\t', ';').asSequence() }
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .toList()

    fun isIpLiteral(s: String): Boolean {
        val t = s.removePrefix("[").removeSuffix("]")
        if (IPV4.matches(t)) return t.split('.').all { (it.toIntOrNull() ?: 999) <= 255 }
        return t.contains(':') && t.all { it in "0123456789abcdefABCDEF:." }
    }

    /** IPs, CIDRs and domains -> unique list of IP strings. A CIDR bigger than [perCidr] is randomly sampled. */
    fun expandIps(input: String?, perCidr: Int, resolveDomains: Boolean = true): List<String> {
        val out = LinkedHashSet<String>()
        for (t in tokens(input)) {
            if (out.size >= HARD_LIMIT) break
            try {
                when {
                    t.contains('/') -> out += expandCidr(t, perCidr)
                    isIpLiteral(t) -> out += InetAddress.getByName(t.removePrefix("[").removeSuffix("]")).hostAddress!!
                    resolveDomains -> InetAddress.getAllByName(t).forEach { a -> a.hostAddress?.let { out += it } }
                }
            } catch (e: Exception) {
                // skip invalid / unresolvable entries
            }
        }
        return out.take(HARD_LIMIT)
    }

    fun expandCidr(cidr: String, perCidr: Int): List<String> {
        val ipPart = cidr.substringBefore('/').trim()
        val pfx = cidr.substringAfter('/').trim().toInt()
        require(isIpLiteral(ipPart)) { "not an IP: $ipPart" }
        val bytes = InetAddress.getByName(ipPart).address
        val bits = bytes.size * 8
        val prefix = pfx.coerceIn(0, bits)
        val hostBits = bits - prefix
        val base = BigInteger(1, bytes).shiftRight(hostBits).shiftLeft(hostBits)
        val size = BigInteger.ONE.shiftLeft(hostBits)
        val limit = perCidr.coerceIn(1, HARD_LIMIT)
        val offsets: Collection<BigInteger> = if (size <= BigInteger.valueOf(limit.toLong())) {
            (0 until size.toInt()).map { BigInteger.valueOf(it.toLong()) }
        } else {
            val set = LinkedHashSet<BigInteger>()
            var guard = 0
            while (set.size < limit && guard < limit * 20) {
                set += randomBelow(size); guard++
            }
            set
        }
        return offsets.map { toAddr(base.add(it), bytes.size) }
    }

    private fun randomBelow(size: BigInteger): BigInteger {
        var r: BigInteger
        do { r = BigInteger(size.bitLength(), rnd) } while (r >= size)
        return r
    }

    private fun toAddr(v: BigInteger, len: Int): String {
        val raw = v.toByteArray()
        val b = ByteArray(len)
        val n = minOf(raw.size, len)
        System.arraycopy(raw, raw.size - n, b, len - n, n)
        return InetAddress.getByAddress(b).hostAddress!!
    }

    data class Endpoint(val host: String, val port: Int, val user: String?, val pass: String?)

    /** Accepts host:port, user:pass@host:port, scheme://user:pass@host:port, host:port:user:pass and [v6]:port. */
    fun parseEndpoint(raw: String, defaultPort: Int): Endpoint? {
        var s = raw.trim().substringAfter("://").trimEnd('/')
        var user: String? = null
        var pass: String? = null
        if ('@' in s) {
            val cred = s.substringBeforeLast('@')
            s = s.substringAfterLast('@')
            user = cred.substringBefore(':')
            pass = cred.substringAfter(':', "")
        }
        val host: String
        val port: Int
        if (s.startsWith("[")) {
            host = s.substringAfter('[').substringBefore(']')
            port = s.substringAfter("]:", "").toIntOrNull() ?: defaultPort
        } else {
            val parts = s.split(':')
            when {
                parts.size == 1 -> { host = parts[0]; port = defaultPort }
                parts.size == 2 -> { host = parts[0]; port = parts[1].toIntOrNull() ?: return null }
                parts.size == 4 && user == null -> {
                    host = parts[0]; port = parts[1].toIntOrNull() ?: return null
                    user = parts[2]; pass = parts[3]
                }
                else -> { host = s; port = defaultPort }
            }
        }
        if (host.isBlank() || port !in 1..65535) return null
        return Endpoint(host, port, user?.takeIf { it.isNotEmpty() }, pass)
    }
}
