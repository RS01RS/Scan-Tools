package com.scantools.app

import android.app.Activity
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import com.scantools.app.scan.ProbeResult
import com.scantools.app.scan.Tools
import com.scantools.app.scan.err
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.CountDownLatch
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/** Scan Tools — Made by (R.S). The page (assets/index.html) is the UI; this class is the bridge. */
class MainActivity : Activity() {

    private lateinit var web: WebView
    private val main = Handler(Looper.getMainLooper())
    private val pool: ExecutorService = Executors.newCachedThreadPool()
    @Volatile private var english = false
    private fun tr(fa: String, en: String) = if (english) en else fa

    // ---------- scan runner ----------
    private inner class Run(val id: String, val tool: String, val values: Map<String, String>) {
        val queue = ConcurrentLinkedQueue<ProbeResult>()
        val done = AtomicInteger()
        val ok = AtomicInteger()
        val good = ConcurrentLinkedQueue<ProbeResult>()
        @Volatile var produced = 0
        @Volatile var counted = -1
        @Volatile var producing = true
        val spDone = AtomicInteger()
        @Volatile var spTotal = 0
        @Volatile var cancelled = false
        @Volatile var state = "prep"
        @Volatile var exec: ExecutorService? = null
        val awake = values["awake"] == "on"
        private fun live() = state == "prep" || state == "running" || state == "speed"
        private val flusher = object : Runnable {
            override fun run() {
                flush()
                if (live()) main.postDelayed(this, 300)
                else if (awake) window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        fun flush() {
            val arr = JSONArray()
            var n = 0
            while (n < 400) {
                val r = queue.poll() ?: break
                val o = JSONObject().put("t", r.target).put("ok", r.ok).put("ms", r.latencyMs).put("d", r.detail)
                if (r.update) o.put("u", 1)
                if (r.update || r.dl >= 0) o.put("dl", r.dl).put("ul", r.ul).put("pg", r.ping)
                if (r.loss >= 0) o.put("ls", r.loss)
                arr.put(o)
                n++
            }
            // Once every target is produced the real total is known (the background count may differ by duplicates).
            val total = if (!producing || counted < 0) produced else maxOf(counted, produced)
            val extra = JSONObject().put("more", producing && counted < 0).put("sd", spDone.get()).put("st", spTotal)
            js("window.STScan&&STScan(${JSONObject.quote(id)},$arr,${done.get()},$total,${ok.get()},${JSONObject.quote(state)},$extra)")
            if (queue.isNotEmpty()) main.post { flush() }
        }

        fun start() {
            if (awake) main.post { window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
            main.post(flusher)
            pool.execute {
                try {
                    if (Tools.wantsCount(tool, values)) pool.execute {
                        try { val c = Tools.count(tool, values); if (!cancelled) counted = c } catch (e: Throwable) { }
                    }
                    val conc = Tools.concurrency(values)
                    val targets = LinkedBlockingQueue<String>(4096)
                    val ex = Executors.newFixedThreadPool(conc)
                    exec = ex
                    val latch = CountDownLatch(conc)
                    repeat(conc) {
                        ex.execute {
                            try {
                                while (!cancelled) {
                                    val t = targets.poll(200, TimeUnit.MILLISECONDS)
                                    if (t == null) { if (!producing && targets.isEmpty()) break else continue }
                                    val r = try { Tools.probe(tool, t, values) } catch (e: Throwable) { ProbeResult(t, false, 0, err(e)) }
                                    if (cancelled) break
                                    queue.add(r)
                                    if (r.ok) { ok.incrementAndGet(); good.add(r) }
                                    done.incrementAndGet()
                                }
                            } catch (e: InterruptedException) {
                            } finally { latch.countDown() }
                        }
                    }
                    // Producer: targets are generated lazily, so testing starts before every range is expanded.
                    try {
                        for (t in Tools.stream(tool, values)) {
                            if (cancelled) break
                            while (!cancelled && !targets.offer(t, 200, TimeUnit.MILLISECONDS)) { }
                            produced++
                            if (!cancelled && state == "prep") state = "running"
                        }
                    } finally { producing = false }
                    latch.await()
                    ex.shutdown()
                    if (cancelled) return@execute
                    if (produced == 0) { state = "empty"; main.post { flush() }; return@execute }
                    if (Tools.wantsSpeed(tool, values) && good.isNotEmpty()) speedPhase()
                    if (!cancelled) { state = "done"; main.post { flush() } }
                } catch (e: Throwable) {
                    if (!cancelled) { state = "error:" + err(e); main.post { flush() } }
                }
            }
        }

        /** After the scan: download / upload / ping for the best working IPs (2 at a time, so tests don't fight). */
        private fun speedPhase() {
            val list = good.sortedBy { it.latencyMs }.take(Tools.speedMax(values))
            if (cancelled) return
            spTotal = list.size
            state = "speed"
            val conc = minOf(2, list.size)
            val ex = Executors.newFixedThreadPool(conc)
            exec = ex
            val next = AtomicInteger()
            val latch = CountDownLatch(conc)
            repeat(conc) {
                ex.execute {
                    try {
                        while (!cancelled) {
                            val i = next.getAndIncrement()
                            if (i >= list.size) break
                            val r = try { Tools.speed(list[i], values) } catch (e: Throwable) { list[i].copy(dl = 0, ul = 0, ping = -1, update = true) }
                            if (cancelled) break
                            queue.add(r)
                            spDone.incrementAndGet()
                        }
                    } finally { latch.countDown() }
                }
            }
            latch.await()
            ex.shutdown()
        }

        fun cancel() {
            cancelled = true
            state = "stopped"
            exec?.shutdownNow()
            main.post { flush(); if (awake) window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
        }
    }

    @Volatile private var run: Run? = null

    // ---------- in-app update (same as VPN Scan) ----------
    private var dm: DownloadManager? = null
    private var updId = -1L
    private var installPending = false
    private var poller: Runnable? = null

    private fun updEvent(done: Long, total: Long, st: String) =
        js("window.RSUpdProgress&&window.RSUpdProgress($done,$total,${JSONObject.quote(st)})")

    private fun startUpdate(url: String, name: String?) {
        try {
            val d = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            dm = d
            if (updId != -1L) d.remove(updId)
            val file = if (name != null && name.lowercase().endsWith(".apk")) name.replace(Regex("[^A-Za-z0-9._-]"), "_") else "scan-tools-update.apk"
            File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), file).let { if (it.exists()) it.delete() }
            val r = DownloadManager.Request(Uri.parse(url))
                .setTitle("Scan Tools")
                .setDescription(tr("دانلود نسخهٔ جدید", "Downloading update"))
                .setMimeType("application/vnd.android.package-archive")
                .addRequestHeader("User-Agent", "Mozilla/5.0 (Linux; Android 14) Scan-Tools/1.0")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
                .setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, file)
            updId = d.enqueue(r)
            installPending = false
            pollUpdate()
        } catch (e: Exception) {
            updId = -1
            updEvent(0, 0, "failed")
        }
    }

    private fun pollUpdate() {
        poller?.let { main.removeCallbacks(it) }
        val p = object : Runnable {
            override fun run() {
                val d = dm ?: return
                if (updId == -1L) return
                try {
                    d.query(DownloadManager.Query().setFilterById(updId)).use { c ->
                        if (c == null || !c.moveToFirst()) { updId = -1; updEvent(0, 0, "failed"); return }
                        val st = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                        val done = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                        val total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                        when (st) {
                            DownloadManager.STATUS_SUCCESSFUL -> { updEvent(done, total, "done"); installUpdate(); return }
                            DownloadManager.STATUS_FAILED -> { d.remove(updId); updId = -1; updEvent(done, total, "failed"); return }
                            else -> updEvent(done, total, when (st) {
                                DownloadManager.STATUS_PAUSED -> "paused"
                                DownloadManager.STATUS_PENDING -> "pending"
                                else -> "running"
                            })
                        }
                    }
                } catch (e: Exception) {
                    updEvent(0, 0, "failed"); return
                }
                main.postDelayed(this, 400)
            }
        }
        poller = p
        main.post(p)
    }

    private fun installUpdate() {
        val d = dm
        if (updId == -1L || d == null) { updEvent(0, 0, "failed"); return }
        if (!packageManager.canRequestPackageInstalls()) {
            installPending = true
            updEvent(0, 0, "permission")
            try { startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))) } catch (e: Exception) { }
            return
        }
        installPending = false
        try {
            val u = d.getUriForDownloadedFile(updId) ?: throw Exception("no file")
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            updEvent(0, 0, "installFailed")
        }
    }

    private fun cancelUpdate() {
        poller?.let { main.removeCallbacks(it) }
        if (updId != -1L) dm?.remove(updId)
        updId = -1
        installPending = false
    }

    override fun onResume() {
        super.onResume()
        if (installPending && packageManager.canRequestPackageInstalls()) installUpdate()
    }

    // ---------- theme: status / navigation bar colours ----------
    @Suppress("DEPRECATION")
    private fun applyBars(light: Boolean) {
        val bg = if (light) 0xFFEAF4FF.toInt() else 0xFF06122B.toInt()
        window.statusBarColor = bg
        window.navigationBarColor = bg
        val d = window.decorView
        val m = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        d.systemUiVisibility = if (light) d.systemUiVisibility or m else d.systemUiVisibility and m.inv()
        web.setBackgroundColor(bg)
    }

    private fun sysDark() =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        js("window.RSOnSysTheme&&window.RSOnSysTheme(${sysDark()})")
    }

    // ---------- activity ----------
    @Suppress("SetJavaScriptEnabled", "DEPRECATION")
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        window.statusBarColor = 0xFF06122B.toInt()
        window.navigationBarColor = 0xFF06122B.toInt()
        web = WebView(this)
        web.setBackgroundColor(0xFF06122B.toInt())
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowFileAccessFromFileURLs = true
            allowUniversalAccessFromFileURLs = true
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView?, cb: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try {
                    startActivityForResult(params.createIntent().setType("*/*"), FILE_REQ); true
                } catch (e: Exception) {
                    fileCb = null; cb.onReceiveValue(null); false
                }
            }
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.scheme == "file") return false
                openExternal(request.url.toString()); return true
            }
        }
        web.addJavascriptInterface(Bridge(), "RSNative")
        if (state != null) web.restoreState(state) else web.loadUrl("file:///android_asset/index.html")
    }

    private var fileCb: ValueCallback<Array<Uri>>? = null

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == FILE_REQ && fileCb != null) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data))
            fileCb = null
            return
        }
        super.onActivityResult(req, res, data)
    }

    override fun onSaveInstanceState(out: Bundle) {
        super.onSaveInstanceState(out)
        web.saveState(out)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("window.RSBack?window.RSBack():false") { r ->
            if (r != "true") {
                @Suppress("DEPRECATION")
                super.onBackPressed()
            }
        }
    }

    override fun onDestroy() {
        poller?.let { main.removeCallbacks(it) }
        run?.cancel()
        pool.shutdownNow()
        web.destroy()
        super.onDestroy()
    }

    private fun js(code: String) = main.post { try { web.evaluateJavascript(code, null) } catch (e: Exception) { } }

    private fun callback(id: String, jsonLiteral: String) = js("window.RSNativeCb&&window.RSNativeCb(${JSONObject.quote(id)},$jsonLiteral)")

    private fun toast(msg: String) = main.post { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }

    private fun openExternal(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: ActivityNotFoundException) {
            toast(tr("برنامه‌ای برای باز کردن این لینک نیست", "No app can open this link"))
        }
    }

    private fun httpGet(url: String, timeoutMs: Int): String? {
        var c: HttpURLConnection? = null
        return try {
            c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = minOf(timeoutMs, 15000)
            c.readTimeout = timeoutMs
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) Scan-Tools/1.0")
            c.setRequestProperty("Accept", "application/vnd.github+json, */*")
            if (c.responseCode == 404) return "404"
            if (c.responseCode / 100 != 2) return null
            c.inputStream.use { inp ->
                val out = ByteArrayOutputStream()
                val buf = ByteArray(16384)
                while (true) {
                    val n = inp.read(buf)
                    if (n <= 0 || out.size() > 4_000_000) break
                    out.write(buf, 0, n)
                }
                String(out.toByteArray(), Charsets.UTF_8)
            }
        } catch (e: Exception) {
            null
        } finally {
            c?.disconnect()
        }
    }

    /** Methods the page calls through window.RSNative. */
    inner class Bridge {
        @JavascriptInterface
        fun version(): String = try {
            val pi = packageManager.getPackageInfo(packageName, 0)
            val code = if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else @Suppress("DEPRECATION") pi.versionCode.toLong()
            "${pi.versionName} (build $code)"
        } catch (e: Exception) { "" }

        @JavascriptInterface
        fun fetch(id: String, url: String, timeoutMs: Int) {
            pool.execute {
                val t = httpGet(url, maxOf(timeoutMs, 3000))
                callback(id, if (t == null) "null" else JSONObject.quote(t))
            }
        }

        @JavascriptInterface
        fun copy(text: String) {
            main.post {
                (getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager)?.setPrimaryClip(ClipData.newPlainText("Scan Tools", text))
            }
        }

        @JavascriptInterface
        fun share(text: String) {
            main.post {
                try {
                    val i = Intent(Intent.ACTION_SEND).setType("text/plain")
                        .putExtra(Intent.EXTRA_SUBJECT, "Scan Tools").putExtra(Intent.EXTRA_TEXT, text)
                    startActivity(Intent.createChooser(i, tr("اشتراک‌گذاری", "Share")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                    toast(tr("اشتراک‌گذاری ممکن نشد", "Couldn't share"))
                }
            }
        }

        @JavascriptInterface
        fun open(url: String) { main.post { openExternal(url) } }

        @JavascriptInterface
        fun save(name: String, text: String) {
            pool.execute {
                try {
                    val data = text.toByteArray(Charsets.UTF_8)
                    if (Build.VERSION.SDK_INT >= 29) {
                        val v = ContentValues().apply {
                            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                            put(MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                        }
                        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: throw Exception("no uri")
                        contentResolver.openOutputStream(uri)?.use { it.write(data) }
                        toast(tr("ذخیره شد: ", "Saved: ") + "Download/" + name)
                    } else {
                        val f = File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), name)
                        FileOutputStream(f).use { it.write(data) }
                        toast(tr("ذخیره شد: ", "Saved: ") + f.absolutePath)
                    }
                } catch (e: Exception) {
                    toast(tr("ذخیره نشد", "Couldn't save"))
                }
            }
        }

        @JavascriptInterface
        fun setLang(lang: String?) { english = lang == "en" }

        @JavascriptInterface
        fun setTheme(light: Boolean) { main.post { applyBars(light) } }

        @JavascriptInterface
        fun sysDark(): Boolean = this@MainActivity.sysDark()

        @JavascriptInterface
        fun startScan(id: String, tool: String, valuesJson: String) {
            val o = JSONObject(valuesJson)
            val v = HashMap<String, String>()
            o.keys().forEach { k -> v[k] = o.optString(k, "") }
            run?.cancel()
            val r = Run(id, tool, v)
            run = r
            r.start()
        }

        @JavascriptInterface
        fun stopScan() { run?.cancel() }

        @JavascriptInterface
        fun startUpdate(url: String, name: String?) { main.post { this@MainActivity.startUpdate(url, name) } }

        @JavascriptInterface
        fun installUpdate() { main.post { this@MainActivity.installUpdate() } }

        @JavascriptInterface
        fun cancelUpdate() { main.post { this@MainActivity.cancelUpdate() } }
    }

    companion object { private const val FILE_REQ = 42 }
}
