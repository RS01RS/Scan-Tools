package com.scantools.app.scan

import java.io.DataInputStream
import java.net.Socket
import java.net.URI
import java.security.cert.X509Certificate
import java.text.SimpleDateFormat
import java.util.Locale
import javax.net.ssl.HttpsURLConnection

data class EdgeCfg(
    val port: Int,
    val tls: Boolean,
    val sni: String,
    val hostHeader: String,
    val path: String,
    val expect: String,
    val marker: String,
    val timeout: Int,
    val downloadKb: Int = 0,
    /** Anti-DPI: send the TLS ClientHello in small TCP pieces. */
    val frag: Boolean = false,
    /** Platform check: the TLS certificate must be valid for the SNI name (proves the IP serves that platform). */
    val certCheck: Boolean = false,
)

private class Url(raw: String) {
    private val u = URI(raw.trim())
    val https = u.scheme.equals("https", true)
    val host: String = u.host ?: throw IllegalArgumentException("bad test URL")
    val port = if (u.port > 0) u.port else if (https) 443 else 80
    val path = (u.rawPath?.ifEmpty { "/" } ?: "/") + (u.rawQuery?.let { "?$it" } ?: "")
    val hostHeader = if ((https && port == 443) || (!https && port == 80)) host else "$host:$port"
    val full = raw.trim()
}

object Probes {

    /** Cloudflare / CDN edge check: TCP -> TLS(SNI) -> HTTP GET, verify status + marker. */
    fun edge(ip: String, c: EdgeCfg): ProbeResult {
        val t0 = System.nanoTime()
        var s: Socket? = null
        try {
            val raw = Net.connect(ip, c.port, c.timeout); s = raw
            val tcp = ms(t0)
            val t1 = System.nanoTime()
            val sock = if (c.tls) Net.tlsAuto(raw, c.sni, c.port, c.timeout, c.frag) else raw
            s = sock
            val tlsMs = ms(t1)
            if (c.tls && c.certCheck && c.sni.isNotBlank()) {
                val session = (sock as? javax.net.ssl.SSLSocket)?.session ?: (sock as? EngineTlsSocket)?.session
                val match = try { session != null && HttpsURLConnection.getDefaultHostnameVerifier().verify(c.sni, session) } catch (e: Exception) { false }
                if (!match) return ProbeResult(ip, false, ms(t0), "cert not for ${c.sni}")
            }
            val host = c.hostHeader.ifBlank { c.sni.ifBlank { ip } }
            val resp = Net.request(sock, "GET", c.path.ifBlank { "/" }, host)
            val total = ms(t0)
            if (!statusMatches(resp.status, c.expect))
                return ProbeResult(ip, false, total, "HTTP ${resp.status} (expected ${c.expect})")
            val text = resp.text
            if (c.marker.isNotBlank() && !text.contains(c.marker, ignoreCase = true))
                return ProbeResult(ip, false, total, "HTTP ${resp.status} but \"${c.marker}\" not found")
            val parts = mutableListOf("HTTP ${resp.status}")
            Regex("""colo=([A-Z]{3})""").find(text)?.let { parts += "colo ${it.groupValues[1]}" }
            resp.header("server")?.let { parts += it.take(20) }
            parts += "tcp ${tcp}ms"
            if (c.tls) parts += "tls ${tlsMs}ms" + if (c.frag) " (frag)" else ""
            if (c.tls && c.certCheck) parts += "cert ✓"
            parts += "total ${total}ms"
            if (c.downloadKb > 0) {
                val kbps = download(ip, c)
                parts += if (kbps > 0) "↓ $kbps KB/s" else "↓ failed"
            }
            return ProbeResult(ip, true, total, parts.joinToString(" · "))
        } catch (e: Exception) {
            return ProbeResult(ip, false, ms(t0), err(e))
        } finally {
            s?.closeQuietly()
        }
    }

    /**
     * Speed test of one edge IP (Cloudflare speed endpoints): best of 3 TCP pings, download of [kb] KB
     * and upload of [upKb] KB. Returns [downKBps, upKBps, pingMs]; 0 / -1 when a part failed.
     */
    fun speed(ip: String, c: EdgeCfg, kb: Int, upKb: Int): LongArray {
        var ping = -1L
        repeat(3) {
            try {
                val t0 = System.nanoTime()
                Net.connect(ip, c.port, c.timeout).closeQuietly()
                val m = ms(t0)
                if (ping < 0 || m < ping) ping = m
            } catch (e: Exception) { }
        }
        if (ping < 0) return longArrayOf(0, 0, -1)
        val dl = download(ip, c.copy(downloadKb = kb))
        val ul = upload(ip, c, upKb)
        return longArrayOf(dl, ul, ping)
    }

    /** Upload speed via speed.cloudflare.com/__up. Returns KB/s, 0 on failure. */
    private fun upload(ip: String, c: EdgeCfg, kb: Int): Long {
        if (kb <= 0) return 0
        var s: Socket? = null
        try {
            val raw = Net.connect(ip, c.port, c.timeout); s = raw
            val sock = if (c.tls) Net.tlsAuto(raw, c.sni, c.port, c.timeout, c.frag) else raw
            s = sock
            sock.soTimeout = maxOf(c.timeout, 10000)
            val body = ByteArray(kb * 1024)
            val t0 = System.nanoTime()
            Net.send(sock, "POST", "/__up", c.hostHeader.ifBlank { c.sni.ifBlank { ip } },
                mapOf("Content-Type" to "application/octet-stream"), body)
            val resp = Net.readResponse(sock.getInputStream(), 8192, headersOnly = true)
            val sec = (System.nanoTime() - t0) / 1e9
            return if (resp.status / 100 == 2 && sec > 0) (kb / sec).toLong() else 0
        } catch (e: Exception) {
            return 0
        } finally {
            s?.closeQuietly()
        }
    }

    /** Download speed via speed.cloudflare.com/__down. Returns KB/s, 0 on failure. */
    private fun download(ip: String, c: EdgeCfg): Long {
        var s: Socket? = null
        try {
            val raw = Net.connect(ip, c.port, c.timeout); s = raw
            val sock = if (c.tls) Net.tlsAuto(raw, c.sni, c.port, c.timeout, c.frag) else raw
            s = sock
            sock.soTimeout = maxOf(c.timeout, 10000)
            val bytes = c.downloadKb.toLong() * 1024
            val t0 = System.nanoTime()
            Net.send(sock, "GET", "/__down?bytes=$bytes", c.hostHeader.ifBlank { c.sni.ifBlank { ip } })
            val inp = sock.getInputStream()
            val buf = ByteArray(16384)
            var got = 0L
            while (got < bytes + 200) {
                val n = inp.read(buf)
                if (n < 0) break
                got += n
            }
            val sec = (System.nanoTime() - t0) / 1e9
            return if (got >= bytes && sec > 0) (bytes / 1024 / sec).toLong() else 0
        } catch (e: Exception) {
            return 0
        } finally {
            s?.closeQuietly()
        }
    }

    /** HTTP proxy: plain GET with absolute URI, or CONNECT tunnel (always used for https test URLs). */
    fun httpProxy(raw: String, mode: String, testUrl: String, expect: String, timeout: Int): ProbeResult {
        val t0 = System.nanoTime()
        val ep = Targets.parseEndpoint(raw, 8080) ?: return ProbeResult(raw, false, 0, "bad format")
        var s: Socket? = null
        try {
            val url = Url(testUrl)
            val auth = ep.user?.let { mapOf("Proxy-Authorization" to "Basic " + base64("$it:${ep.pass.orEmpty()}")) }
                ?: emptyMap()
            val sock = Net.connect(ep.host, ep.port, timeout); s = sock
            val tcp = ms(t0)
            val useConnect = mode.equals("CONNECT", true) || url.https
            val resp = if (useConnect) {
                val target = "${url.host}:${url.port}"
                Net.send(sock, "CONNECT", target, target, auth)
                val cr = Net.readResponse(sock.getInputStream(), 8192, headersOnly = true)
                if (cr.status != 200) return ProbeResult(raw, false, ms(t0), "CONNECT refused: HTTP ${cr.status}")
                var tunnel: Socket = sock
                if (url.https) { tunnel = Net.tls(sock, url.host, url.port, timeout); s = tunnel }
                Net.request(tunnel, "GET", url.path, url.hostHeader)
            } else {
                Net.request(sock, "GET", url.full, url.hostHeader, auth)
            }
            val total = ms(t0)
            if (!statusMatches(resp.status, expect))
                return ProbeResult(raw, false, total, "HTTP ${resp.status} (expected $expect)")
            return ProbeResult(
                raw, true, total,
                "HTTP ${resp.status} · ${if (useConnect) "CONNECT" else "GET"} · tcp ${tcp}ms · total ${total}ms",
            )
        } catch (e: Exception) {
            return ProbeResult(raw, false, ms(t0), err(e))
        } finally {
            s?.closeQuietly()
        }
    }

    /** SOCKS5 (RFC 1928, user/pass RFC 1929) CONNECT to the test URL, then HTTP(S) GET through it. */
    fun socks5(raw: String, testUrl: String, expect: String, timeout: Int): ProbeResult {
        val t0 = System.nanoTime()
        fun fail(m: String) = ProbeResult(raw, false, ms(t0), m)
        val ep = Targets.parseEndpoint(raw, 1080) ?: return fail("bad format")
        var s: Socket? = null
        try {
            val url = Url(testUrl)
            val sock = Net.connect(ep.host, ep.port, timeout); s = sock
            val tcp = ms(t0)
            val out = sock.getOutputStream()
            val inp = DataInputStream(sock.getInputStream())
            out.write(if (ep.user != null) byteArrayOf(5, 2, 0, 2) else byteArrayOf(5, 1, 0))
            out.flush()
            if (inp.readUnsignedByte() != 5) return fail("not a SOCKS5 server")
            when (val method = inp.readUnsignedByte()) {
                0 -> {}
                2 -> {
                    val u = ep.user.orEmpty().toByteArray()
                    val p = ep.pass.orEmpty().toByteArray()
                    out.write(byteArrayOf(1, u.size.toByte()) + u + byteArrayOf(p.size.toByte()) + p)
                    out.flush()
                    inp.readUnsignedByte()
                    if (inp.readUnsignedByte() != 0) return fail("auth failed")
                }
                0xFF -> return fail(if (ep.user == null) "auth required" else "auth method rejected")
                else -> return fail("unsupported method $method")
            }
            val hb = url.host.toByteArray()
            out.write(byteArrayOf(5, 1, 0, 3, hb.size.toByte()) + hb + byteArrayOf((url.port shr 8).toByte(), url.port.toByte()))
            out.flush()
            inp.readUnsignedByte()
            val rep = inp.readUnsignedByte()
            inp.readUnsignedByte()
            val addrLen = when (inp.readUnsignedByte()) {
                1 -> 4
                4 -> 16
                3 -> inp.readUnsignedByte()
                else -> return fail("bad reply")
            }
            inp.readFully(ByteArray(addrLen + 2))
            if (rep != 0) return fail("CONNECT failed: ${socksError(rep)}")
            var tunnel: Socket = sock
            if (url.https) { tunnel = Net.tls(sock, url.host, url.port, timeout); s = tunnel }
            val resp = Net.request(tunnel, "GET", url.path, url.hostHeader)
            val total = ms(t0)
            if (!statusMatches(resp.status, expect)) return fail("HTTP ${resp.status} (expected $expect)")
            return ProbeResult(
                raw, true, total,
                "HTTP ${resp.status} · ${if (ep.user != null) "auth · " else ""}tcp ${tcp}ms · total ${total}ms",
            )
        } catch (e: Exception) {
            return fail(err(e))
        } finally {
            s?.closeQuietly()
        }
    }

    private fun socksError(rep: Int) = when (rep) {
        1 -> "general failure"; 2 -> "not allowed"; 3 -> "network unreachable"; 4 -> "host unreachable"
        5 -> "refused"; 6 -> "TTL expired"; 7 -> "command not supported"; 8 -> "address type not supported"
        else -> "code $rep"
    }

    /** TLS hostname probe. Target format: "ip|sni". */
    fun sni(target: String, port: Int, httpCheck: Boolean, timeout: Int): ProbeResult {
        val ip = target.substringBefore('|')
        val name = target.substringAfter('|')
        val label = "$name @ $ip"
        val t0 = System.nanoTime()
        var s: Socket? = null
        try {
            val raw = Net.connect(ip, port, timeout); s = raw
            val tcp = ms(t0)
            val t1 = System.nanoTime()
            val ssl = Net.tls(raw, name, port, timeout); s = ssl
            val hs = ms(t1)
            val session = ssl.session
            val chain = session.peerCertificates.filterIsInstance<X509Certificate>().toTypedArray()
            val leaf = chain.firstOrNull()
            val trusted = try { Net.defaultTm.checkServerTrusted(chain, "RSA"); true } catch (e: Exception) { false }
            val match = try { HttpsURLConnection.getDefaultHostnameVerifier().verify(name, session) } catch (e: Exception) { false }
            val parts = mutableListOf(session.protocol ?: "TLS", "tcp ${tcp}ms", "hs ${hs}ms")
            if (leaf != null) {
                parts += "CN=" + cn(leaf.subjectX500Principal.name)
                parts += "issuer " + cn(leaf.issuerX500Principal.name)
                parts += "exp " + SimpleDateFormat("yyyy-MM-dd", Locale.US).format(leaf.notAfter)
            }
            parts += if (trusted) "trusted ✓" else "untrusted ✗"
            parts += if (match) "name match ✓" else "name mismatch ✗"
            if (httpCheck) {
                parts += try { "HTTP " + Net.request(ssl, "GET", "/", name, limit = 4096).status } catch (e: Exception) { "HTTP ✗ " + err(e) }
            }
            return ProbeResult(label, true, tcp + hs, parts.joinToString(" · "))
        } catch (e: Exception) {
            return ProbeResult(label, false, ms(t0), err(e))
        } finally {
            s?.closeQuietly()
        }
    }

    private fun cn(dn: String): String =
        Regex("""CN=([^,]+)""").find(dn)?.groupValues?.get(1) ?: dn.take(30)

    data class DnsCfg(
        val domain: String,
        val modes: Set<String>,
        val dohPath: String,
        val tlsName: String,
        val tunnelDomain: String,
        val timeout: Int,
    )

    /** Resolver check over UDP/TCP/DoT/DoH plus DNS-tunnel readiness (random subdomain TXT query). */
    fun dns(target: String, c: DnsCfg): ProbeResult {
        val parts = mutableListOf<String>()
        var best = Long.MAX_VALUE
        var anyOk = false
        fun run(label: String, block: () -> Dns.Resp) {
            val t0 = System.nanoTime()
            try {
                val r = block()
                val m = ms(t0)
                val good = r.rcode == 0 || r.rcode == 3
                if (good) { anyOk = true; best = minOf(best, m) }
                parts += "$label ${if (good) "✓" else "✗"} ${m}ms ${Dns.rcodeName(r.rcode)}"
            } catch (e: Exception) {
                parts += "$label ✗ ${err(e)}"
            }
        }
        if (target.startsWith("https://", true)) {
            val u = URI(target)
            val host = u.host ?: return ProbeResult(target, false, 0, "bad URL")
            val port = if (u.port > 0) u.port else 443
            val path = u.rawPath?.ifEmpty { null } ?: c.dohPath
            run("DoH") { Net.withSocket(host, port, c.timeout, true, host) { Dns.doh(it, host, path, c.domain, Dns.A) } }
            return ProbeResult(target, anyOk, if (anyOk) best else 0, parts.joinToString(" · "))
        }
        val ip = target
        if ("UDP" in c.modes) run("UDP") { Dns.udp(ip, 53, c.domain, Dns.A, c.timeout) }
        if ("TCP" in c.modes) run("TCP") { Net.withSocket(ip, 53, c.timeout, false, null) { Dns.stream(it, c.domain, Dns.A) } }
        if ("DoT" in c.modes) run("DoT") { Net.withSocket(ip, 853, c.timeout, true, c.tlsName) { Dns.stream(it, c.domain, Dns.A) } }
        if ("DoH" in c.modes) run("DoH") {
            Net.withSocket(ip, 443, c.timeout, true, c.tlsName) { Dns.doh(it, c.tlsName.ifBlank { ip }, c.dohPath, c.domain, Dns.A) }
        }
        val tunnel = c.tunnelDomain.trim().trim('.')
        if (tunnel.isNotEmpty()) {
            val t0 = System.nanoTime()
            val sub = (1..12).map { "abcdefghijklmnopqrstuvwxyz0123456789".random() }.joinToString("") + "." + tunnel
            try {
                val r = Dns.udp(ip, 53, sub, Dns.TXT, c.timeout)
                val m = ms(t0)
                val ready = r.rcode != 2 && r.rcode != 5
                parts += "Tunnel ${if (ready) "✓" else "✗"} ${m}ms ${Dns.rcodeName(r.rcode)}${if (r.truncated) " TC" else ""}"
                return ProbeResult(ip, ready, m, parts.joinToString(" · "))
            } catch (e: Exception) {
                parts += "Tunnel ✗ ${err(e)}"
                return ProbeResult(ip, false, ms(t0), parts.joinToString(" · "))
            }
        }
        return ProbeResult(ip, anyOk, if (anyOk) best else 0, parts.joinToString(" · "))
    }
}
