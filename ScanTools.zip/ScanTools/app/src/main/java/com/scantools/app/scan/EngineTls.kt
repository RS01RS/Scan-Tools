package com.scantools.app.scan

import java.io.EOFException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.Socket
import java.net.SocketException
import java.nio.ByteBuffer
import java.util.Random
import javax.net.ssl.SSLEngine
import javax.net.ssl.SSLEngineResult
import javax.net.ssl.SSLEngineResult.HandshakeStatus
import javax.net.ssl.SSLException

/**
 * TLS over an already-connected socket, driven by an SSLEngine so we control exactly how bytes hit the wire.
 * With [fragment] on, the first handshake flight (the ClientHello) is written as many small TCP segments
 * with short pauses between them. The TLS bytes themselves are unchanged (same records, same SNI);
 * only their split into packets differs, which defeats DPI boxes that look for the SNI in one packet.
 */
class EngineTlsSocket(private val raw: Socket, private val engine: SSLEngine) : Socket() {
    private val rin: InputStream = raw.getInputStream()
    private val rout: OutputStream = raw.getOutputStream()
    private var netIn: ByteBuffer = ByteBuffer.allocate(engine.session.packetBufferSize)   // write mode
    private var appIn: ByteBuffer = ByteBuffer.allocate(engine.session.applicationBufferSize) // write mode
    private var netOut: ByteBuffer = ByteBuffer.allocate(engine.session.packetBufferSize)
    private val rnd = Random()
    @Volatile private var eof = false
    @Volatile private var closedFlag = false

    fun handshake(fragment: Boolean) {
        engine.beginHandshake()
        var first = fragment
        var hs = engine.handshakeStatus
        var guard = 0
        while (hs != HandshakeStatus.FINISHED && hs != HandshakeStatus.NOT_HANDSHAKING) {
            if (++guard > 10_000) throw SSLException("handshake did not finish")
            hs = when (hs) {
                HandshakeStatus.NEED_WRAP -> {
                    val r = wrap(EMPTY, first); first = false
                    if (r.status == SSLEngineResult.Status.CLOSED) throw SSLException("closed during handshake")
                    r.handshakeStatus
                }
                HandshakeStatus.NEED_TASK -> { runTasks(); engine.handshakeStatus }
                else -> { // NEED_UNWRAP (and NEED_UNWRAP_AGAIN on newer runtimes)
                    val r = unwrap() ?: throw EOFException("connection closed during handshake")
                    if (r.status == SSLEngineResult.Status.CLOSED) throw SSLException("closed during handshake")
                    r.handshakeStatus
                }
            }
        }
    }

    private fun runTasks() {
        while (true) (engine.delegatedTask ?: return).run()
    }

    /** Encrypts [src] and writes it out. Returns the last engine result. */
    private fun wrap(src: ByteBuffer, fragment: Boolean): SSLEngineResult {
        while (true) {
            netOut.clear()
            val r = engine.wrap(src, netOut)
            when (r.status) {
                SSLEngineResult.Status.BUFFER_OVERFLOW -> { netOut = ByteBuffer.allocate(netOut.capacity() * 2); continue }
                else -> {
                    netOut.flip()
                    if (netOut.hasRemaining()) writeNet(netOut, fragment)
                    if (r.handshakeStatus == HandshakeStatus.NEED_TASK) runTasks()
                    return r
                }
            }
        }
    }

    private fun writeNet(buf: ByteBuffer, fragment: Boolean) {
        val b = ByteArray(buf.remaining())
        buf.get(b)
        if (!fragment) { rout.write(b); rout.flush(); return }
        // Record header first, then the hello body in small random pieces (SNI ends up split across packets).
        var i = 0
        var piece = minOf(5, b.size)
        while (i < b.size) {
            val n = minOf(piece, b.size - i)
            rout.write(b, i, n)
            rout.flush()
            i += n
            if (i < b.size) {
                try { Thread.sleep(2L + rnd.nextInt(5)) } catch (e: InterruptedException) { throw SocketException("interrupted") }
            }
            piece = 6 + rnd.nextInt(30)
        }
    }

    /** One successful unwrap step (reads from the network as needed). Null on clean EOF. */
    private fun unwrap(): SSLEngineResult? {
        while (true) {
            netIn.flip()
            val r = try { engine.unwrap(netIn, appIn) } finally { netIn.compact() }
            when (r.status) {
                SSLEngineResult.Status.BUFFER_UNDERFLOW -> {
                    if (!netIn.hasRemaining()) netIn = grow(netIn, engine.session.packetBufferSize)
                    val n = rin.read(netIn.array(), netIn.arrayOffset() + netIn.position(), netIn.remaining())
                    if (n < 0) { eof = true; return null }
                    netIn.position(netIn.position() + n)
                }
                SSLEngineResult.Status.BUFFER_OVERFLOW -> appIn = grow(appIn, engine.session.applicationBufferSize)
                else -> {
                    if (r.handshakeStatus == HandshakeStatus.NEED_TASK) runTasks()
                    return r
                }
            }
        }
    }

    private fun grow(b: ByteBuffer, min: Int): ByteBuffer {
        val n = ByteBuffer.allocate(maxOf(b.capacity() * 2, b.position() + min))
        b.flip(); n.put(b)
        return n
    }

    private val input = object : InputStream() {
        override fun read(): Int {
            val one = ByteArray(1)
            return if (read(one, 0, 1) <= 0) -1 else one[0].toInt() and 0xFF
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (len == 0) return 0
            while (appIn.position() == 0) {
                if (eof || closedFlag) return -1
                val r = unwrap() ?: return -1
                if (r.status == SSLEngineResult.Status.CLOSED && appIn.position() == 0) { eof = true; return -1 }
                if (r.handshakeStatus == HandshakeStatus.NEED_WRAP) wrap(EMPTY, false) // post-handshake reply
            }
            appIn.flip()
            val n = minOf(len, appIn.remaining())
            appIn.get(b, off, n)
            appIn.compact()
            return n
        }

        override fun available(): Int = appIn.position()
    }

    private val output = object : OutputStream() {
        override fun write(b: Int) = write(byteArrayOf(b.toByte()), 0, 1)
        override fun write(b: ByteArray, off: Int, len: Int) {
            val src = ByteBuffer.wrap(b, off, len)
            while (src.hasRemaining()) {
                val r = wrap(src, false)
                if (r.status == SSLEngineResult.Status.CLOSED) throw SocketException("TLS closed")
            }
        }
        override fun flush() = rout.flush()
    }

    val session get() = engine.session

    override fun getInputStream(): InputStream = input
    override fun getOutputStream(): OutputStream = output
    override fun setSoTimeout(timeout: Int) { raw.soTimeout = timeout }
    override fun getSoTimeout(): Int = raw.soTimeout
    override fun getInetAddress(): InetAddress? = raw.inetAddress
    override fun isConnected(): Boolean = raw.isConnected
    override fun isClosed(): Boolean = closedFlag || raw.isClosed

    override fun close() {
        if (closedFlag) return
        closedFlag = true
        try { engine.closeOutbound() } catch (e: Exception) { }
        raw.closeQuietly()
    }

    companion object { private val EMPTY: ByteBuffer = ByteBuffer.allocate(0) }
}
