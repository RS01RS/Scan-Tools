package com.scantools.app.scan

import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.random.Random

/** Minimal DNS client: UDP, TCP, DoT and DoH (RFC 1035 / 7858 / 8484). */
object Dns {
    const val A = 1
    const val TXT = 16

    class Resp(val rcode: Int, val answers: Int, val truncated: Boolean, val size: Int)

    fun query(name: String, qtype: Int, id: Int, edns: Boolean = true): ByteArray {
        val out = ByteArrayOutputStream()
        fun u16(v: Int) { out.write((v shr 8) and 0xFF); out.write(v and 0xFF) }
        u16(id); u16(0x0100); u16(1); u16(0); u16(0); u16(if (edns) 1 else 0)
        name.trimEnd('.').split('.').filter { it.isNotEmpty() }.forEach { label ->
            val b = label.toByteArray(Charsets.US_ASCII)
            require(b.size in 1..63) { "bad label" }
            out.write(b.size); out.write(b, 0, b.size)
        }
        out.write(0); u16(qtype); u16(1)
        if (edns) { out.write(0); u16(41); u16(1232); u16(0); u16(0); u16(0) }
        return out.toByteArray()
    }

    fun parse(b: ByteArray, len: Int, expectId: Int): Resp {
        if (len < 12) throw IOException("short DNS reply")
        val id = ((b[0].toInt() and 0xFF) shl 8) or (b[1].toInt() and 0xFF)
        if (id != expectId) throw IOException("DNS id mismatch")
        val flags = ((b[2].toInt() and 0xFF) shl 8) or (b[3].toInt() and 0xFF)
        if ((flags and 0x8000) == 0) throw IOException("not a DNS response")
        val an = ((b[6].toInt() and 0xFF) shl 8) or (b[7].toInt() and 0xFF)
        return Resp(flags and 0xF, an, (flags and 0x0200) != 0, len)
    }

    fun rcodeName(r: Int): String = when (r) {
        0 -> "NOERROR"; 1 -> "FORMERR"; 2 -> "SERVFAIL"; 3 -> "NXDOMAIN"
        4 -> "NOTIMP"; 5 -> "REFUSED"; else -> "RCODE$r"
    }

    fun udp(server: String, port: Int, name: String, qtype: Int, timeout: Int): Resp {
        val id = Random.nextInt(1, 0xFFFF)
        val q = query(name, qtype, id)
        return DatagramSocket().use { ds ->
            ds.soTimeout = timeout
            ds.send(DatagramPacket(q, q.size, InetSocketAddress(server, port)))
            val buf = ByteArray(4096)
            val deadline = System.currentTimeMillis() + timeout
            while (true) {
                val p = DatagramPacket(buf, buf.size)
                ds.receive(p)
                try {
                    return parse(buf, p.length, id)
                } catch (e: IOException) {
                    if (System.currentTimeMillis() > deadline) throw e
                }
            }
            @Suppress("UNREACHABLE_CODE")
            throw IOException("unreachable")
        }
    }

    /** DNS over a stream (plain TCP or DoT): 2-byte length prefix. */
    fun stream(sock: Socket, name: String, qtype: Int): Resp {
        val id = Random.nextInt(1, 0xFFFF)
        val q = query(name, qtype, id)
        val out = sock.getOutputStream()
        out.write(byteArrayOf((q.size shr 8).toByte(), q.size.toByte()) + q)
        out.flush()
        val inp = DataInputStream(sock.getInputStream())
        val len = inp.readUnsignedShort()
        val buf = ByteArray(len)
        inp.readFully(buf)
        return parse(buf, len, id)
    }

    fun doh(sock: Socket, host: String, path: String, name: String, qtype: Int): Resp {
        val q = query(name, qtype, 0)
        val r = Net.request(
            sock, "POST", path.ifBlank { "/dns-query" }, host,
            mapOf("Content-Type" to "application/dns-message", "Accept" to "application/dns-message"), q,
        )
        if (r.status != 200) throw IOException("HTTP ${r.status}")
        return parse(r.body, r.body.size, 0)
    }
}
