package com.scantools.app.scan

/** The six scanners: how each turns the form values into targets, and how each target is tested. */
object Tools {
    private fun Map<String, String>.int(k: String, d: Int) = this[k]?.trim()?.toIntOrNull() ?: d
    private fun Map<String, String>.str(k: String) = this[k]?.trim().orEmpty()

    private fun edgeCfg(v: Map<String, String>) = EdgeCfg(
        port = v.int("port", 443),
        tls = v["tls"] != "off",
        sni = v.str("sni"),
        hostHeader = v.str("host"),
        path = v.str("path"),
        expect = v.str("expect"),
        marker = v.str("marker"),
        timeout = v.int("timeout", 2000),
        downloadKb = v.int("download", 0),
        frag = v["frag"] == "on",
        certCheck = v["cert"] == "on",
    )

    fun concurrency(v: Map<String, String>): Int {
        val c = v.int("concurrency", 32).coerceIn(1, 256)
        return if (v["limited"] == "on") minOf(c, 8) else c
    }

    // ---------- Scan IPs ("cf"): ports, anti-DPI, scan rate, speed test ----------

    /** Cloudflare's plain-HTTP ports; with TLS = "auto" these are tested without TLS. */
    private val HTTP_PORTS = setOf(80, 8080, 8880, 2052, 2082, 2086, 2095)

    /** Ports chosen on the page (sent as "portList"); falls back to the single "port" field. */
    fun ports(v: Map<String, String>): List<Int> {
        val l = v.str("portList").split(',').mapNotNull { it.trim().toIntOrNull() }.filter { it in 1..65535 }.distinct()
        return l.ifEmpty { listOf(v.int("port", 443)) }
    }

    private fun tlsFor(port: Int, mode: String) = when (mode) {
        "off" -> false
        "on" -> true
        else -> port !in HTTP_PORTS
    }

    /** "1.2.3.4" (single port), "1.2.3.4:2053" or "[v6]:2053" (several ports). */
    private fun label(ip: String, port: Int, multi: Boolean) =
        if (!multi) ip else if (ip.contains(':')) "[$ip]:$port" else "$ip:$port"

    private fun split(label: String, defPort: Int): Pair<String, Int> {
        if (label.startsWith("[")) {
            return label.substringAfter('[').substringBefore(']') to (label.substringAfter("]:", "").toIntOrNull() ?: defPort)
        }
        if (label.count { it == ':' } == 1) {
            return label.substringBefore(':') to (label.substringAfter(':').toIntOrNull() ?: defPort)
        }
        return label to defPort
    }

    /** Timeout after the low-bandwidth / limited-network adjustments. */
    private fun timeout(v: Map<String, String>, d: Int): Int {
        var t = v.int("timeout", d).coerceAtLeast(300)
        if (v["lowbw"] == "on") t = maxOf(t * 2, 4000)
        if (v["limited"] == "on") t = t * 3 / 2
        return t
    }

    /** Attempts per target: balanced = 2 (retries flaky network errors), fast = 1, limited mode adds one. */
    private fun attempts(v: Map<String, String>): Int {
        var n = if (v["effort"] == "fast") 1 else 2
        if (v["limited"] == "on") n++
        return n
    }

    private fun cfCfg(v: Map<String, String>, port: Int) = edgeCfg(v).copy(
        port = port, tls = tlsFor(port, v.str("tls")), hostHeader = "", path = "/cdn-cgi/trace",
        expect = "200", marker = "colo=", timeout = timeout(v, 2000), downloadKb = 0, frag = v["frag"] == "on",
    )

    private fun cfProbe(label: String, v: Map<String, String>): ProbeResult {
        val (ip, port) = split(label, ports(v).first())
        val cfg = cfCfg(v, port)
        val tries = attempts(v)
        var r = Probes.edge(ip, cfg)
        var n = 1
        // Retry only network-level failures (timeouts, resets); a wrong HTTP answer won't change on retry.
        while (!r.ok && n < tries && !r.detail.startsWith("HTTP ")) { r = Probes.edge(ip, cfg); n++ }
        return r.copy(target = label, detail = if (n > 1) r.detail + " · try $n" else r.detail)
    }

    private fun edgeProbe(ip: String, v: Map<String, String>): ProbeResult {
        val cfg = edgeCfg(v)
        val tries = if (v["effort"] == "fast") 1 else 2
        var r = Probes.edge(ip, cfg)
        var n = 1
        while (!r.ok && n < tries && !r.detail.startsWith("HTTP ") && !r.detail.startsWith("cert ")) { r = Probes.edge(ip, cfg); n++ }
        return if (n > 1) r.copy(detail = r.detail + " · try $n") else r
    }

    fun wantsCount(tool: String, v: Map<String, String>) = tool == "cf" && v["count"] == "on" && v["__list"] == null
    fun wantsSpeed(tool: String, v: Map<String, String>) = tool == "cf" && v["speed"] == "on"
    fun speedMax(v: Map<String, String>) = v.int("speedMax", 20).coerceIn(1, 200)

    private fun cfSource(v: Map<String, String>) = if (v["ttype"] == "domains") v["domains"] else v["targets"]

    /** Targets to test, produced lazily so the scan starts right away. */
    fun stream(tool: String, v: Map<String, String>): Sequence<String> {
        v["__list"]?.let { list -> return list.lines().map { it.trim() }.filter { it.isNotEmpty() }.distinct().asSequence() }
        if (tool == "edge") {
            val per = v.int("perCidr", 20)
            return if (v["dnsRanges"] == "on") Targets.ipSeqDnsRanges(v["targets"], per) else Targets.ipSeq(v["targets"], per)
        }
        if (tool == "cf") {
            val ports = ports(v)
            val multi = ports.size > 1
            return Targets.ipSeq(cfSource(v), v.int("perCidr", 20)).flatMap { ip -> ports.asSequence().map { label(ip, it, multi) } }
        }
        return prepare(tool, v).asSequence()
    }

    /** Exact number of targets [stream] will produce (resolves domains / samples ranges again). */
    fun count(tool: String, v: Map<String, String>): Int =
        if (tool == "cf") Targets.ipSeq(cfSource(v), v.int("perCidr", 20)).count() * ports(v).size
        else prepare(tool, v).size

    /** Speed test of a working Scan IPs result; returns the same row with dl / ul / ping filled in. */
    fun speed(r: ProbeResult, v: Map<String, String>): ProbeResult {
        val (ip, port) = split(r.target, ports(v).first())
        val kb = v.int("speedKb", 1024).coerceIn(64, 50_000)
        val sp = Probes.speed(ip, cfCfg(v, port).copy(timeout = maxOf(timeout(v, 2000), 4000)), kb, maxOf(64, kb / 4))
        return r.copy(dl = sp[0], ul = sp[1], ping = sp[2], update = true)
    }

    fun prepare(tool: String, v: Map<String, String>): List<String> {
        // "Retest working": the page sends the exact list to test again
        v["__list"]?.let { list -> return list.lines().map { it.trim() }.filter { it.isNotEmpty() }.distinct() }
        val per = v.int("perCidr", 20)
        return when (tool) {
            "cf", "edge" -> Targets.expandIps(v["targets"], per)
            "http", "socks" -> Targets.tokens(v["targets"]).distinct()
            "sni" -> {
                val ips = Targets.expandIps(v["ips"], v.int("perCidr", 5))
                val names = Targets.tokens(v["snis"]).distinct()
                ips.flatMap { ip -> names.map { "$ip|$it" } }.take(Targets.HARD_LIMIT)
            }
            "dns" -> Targets.tokens(v["targets"]).flatMap {
                if (it.startsWith("https://", true)) listOf(it) else Targets.expandIps(it, per)
            }.distinct()
            else -> emptyList()
        }
    }

    fun probe(tool: String, t: String, v: Map<String, String>): ProbeResult = when (tool) {
        "cf" -> cfProbe(t, v)
        "edge" -> edgeProbe(t, v)
        "http" -> Probes.httpProxy(t, v.str("mode"), v.str("url"), v.str("expect"), v.int("timeout", 5000))
        "socks" -> Probes.socks5(t, v.str("url"), v.str("expect"), v.int("timeout", 5000))
        "sni" -> Probes.sni(t, v.int("port", 443), v["http"] == "on", v.int("timeout", 3000))
        "dns" -> Probes.dns(
            t,
            Probes.DnsCfg(
                domain = v.str("domain").ifEmpty { "google.com" },
                modes = v.str("modes").split(',').map { it.trim() }.filter { it.isNotEmpty() }.toSet(),
                dohPath = v.str("dohPath").ifEmpty { "/dns-query" },
                tlsName = v.str("tlsName"),
                tunnelDomain = v.str("tunnel"),
                timeout = v.int("timeout", 3000),
            ),
        )
        else -> ProbeResult(t, false, 0, "unknown tool")
    }
}
