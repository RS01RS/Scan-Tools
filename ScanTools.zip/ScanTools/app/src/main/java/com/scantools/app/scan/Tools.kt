package com.scantools.app.scan

/** The six scanners: how each turns the form values into targets, and how each target is tested. */
object Tools {
    private fun Map<String, String>.int(k: String, d: Int) = this[k]?.trim()?.toIntOrNull() ?: d
    private fun Map<String, String>.str(k: String) = this[k]?.trim().orEmpty()

    private fun edgeCfg(v: Map<String, String>) = EdgeCfg(
        port = v.int("port", 443),
        tls = v["tls"] != "off",
        sni = v.str("sni"),
        hostHeader = v.str("host"),
        path = v.str("path"),
        expect = v.str("expect"),
        marker = v.str("marker"),
        timeout = v.int("timeout", 2000),
        downloadKb = v.int("download", 0),
    )

    fun concurrency(v: Map<String, String>) = v.int("concurrency", 32).coerceIn(1, 256)

    fun prepare(tool: String, v: Map<String, String>): List<String> {
        // "Retest working": the page sends the exact list to test again
        v["__list"]?.let { list -> return list.lines().map { it.trim() }.filter { it.isNotEmpty() }.distinct() }
        val per = v.int("perCidr", 20)
        return when (tool) {
            "cf", "edge" -> Targets.expandIps(v["targets"], per)
            "http", "socks" -> Targets.tokens(v["targets"]).distinct()
            "sni" -> {
                val ips = Targets.expandIps(v["ips"], v.int("perCidr", 5))
                val names = Targets.tokens(v["snis"]).distinct()
                ips.flatMap { ip -> names.map { "$ip|$it" } }.take(Targets.HARD_LIMIT)
            }
            "dns" -> Targets.tokens(v["targets"]).flatMap {
                if (it.startsWith("https://", true)) listOf(it) else Targets.expandIps(it, per)
            }.distinct()
            else -> emptyList()
        }
    }

    fun probe(tool: String, t: String, v: Map<String, String>): ProbeResult = when (tool) {
        "cf" -> Probes.edge(t, edgeCfg(v).copy(hostHeader = "", path = "/cdn-cgi/trace", expect = "200", marker = "colo="))
        "edge" -> Probes.edge(t, edgeCfg(v))
        "http" -> Probes.httpProxy(t, v.str("mode"), v.str("url"), v.str("expect"), v.int("timeout", 5000))
        "socks" -> Probes.socks5(t, v.str("url"), v.str("expect"), v.int("timeout", 5000))
        "sni" -> Probes.sni(t, v.int("port", 443), v["http"] == "on", v.int("timeout", 3000))
        "dns" -> Probes.dns(
            t,
            Probes.DnsCfg(
                domain = v.str("domain").ifEmpty { "google.com" },
                modes = v.str("modes").split(',').map { it.trim() }.filter { it.isNotEmpty() }.toSet(),
                dohPath = v.str("dohPath").ifEmpty { "/dns-query" },
                tlsName = v.str("tlsName"),
                tunnelDomain = v.str("tunnel"),
                timeout = v.int("timeout", 3000),
            ),
        )
        else -> ProbeResult(t, false, 0, "unknown tool")
    }
}
