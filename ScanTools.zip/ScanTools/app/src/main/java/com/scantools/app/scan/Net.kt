package com.scantools.app.scan

import java.io.ByteArrayOutputStream
import java.io.EOFException
import java.io.IOException
import java.io.InputStream
import java.net.ConnectException
import java.net.InetSocketAddress
import java.net.NoRouteToHostException
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.security.KeyStore
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLException
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import javax.net.ssl.TrustManager
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509TrustManager

data class ProbeResult(
    val target: String,
    val ok: Boolean,
    val latencyMs: Long,
    val detail: String,
)

fun ms(t0: Long): Long = (System.nanoTime() - t0) / 1_000_000

fun Socket.closeQuietly() {
    try { close() } catch (e: Exception) { }
}

fun err(e: Throwable): String = when (e) {
    is SocketTimeoutException -> "timeout"
    is ConnectException -> "connect failed"
    is NoRouteToHostException -> "no route"
    is UnknownHostException -> "unknown host"
    is SSLException -> "TLS error" + (e.message?.let { ": " + it.take(50) } ?: "")
    is EOFException -> "connection closed"
    else -> (e.message ?: e.javaClass.simpleName).take(60)
}

fun statusMatches(status: Int, expect: String?): Boolean {
    val e = expect?.trim().orEmpty()
    if (e.isEmpty() || e.equals("any", true)) return true
    return e.split(',', ' ').map { it.trim() }.filter { it.isNotEmpty() }.any { t ->
        if (t.endsWith("xx", true)) t[0].digitToIntOrNull() == status / 100 else t.toIntOrNull() == status
    }
}

fun base64(s: String): String {
    val tbl = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    val b = s.toByteArray(Charsets.UTF_8)
    val sb = StringBuilder()
    var i = 0
    while (i < b.size) {
        val n = minOf(3, b.size - i)
        var v = 0
        for (k in 0 until 3) v = (v shl 8) or (if (k < n) (b[i + k].toInt() and 0xFF) else 0)
        for (k in 0 until 4) sb.append(if (k <= n) tbl[(v shr (18 - 6 * k)) and 0x3F] else '=')
        i += 3
    }
    return sb.toString()
}

class HttpResp(val status: Int, val head: String, val body: ByteArray) {
    fun header(name: String): String? = head.lineSequence()
        .firstOrNull { it.startsWith("$name:", ignoreCase = true) }
        ?.substringAfter(':')?.trim()
    val text: String get() = head + "\r\n\r\n" + String(body, Charsets.ISO_8859_1)
}

object Net {
    /** Accepts every certificate: scanners must reach edges even when SNI/cert don't match. */
    val insecureFactory: SSLSocketFactory by lazy {
        val tm = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
        }
        SSLContext.getInstance("TLS").apply { init(null, arrayOf<TrustManager>(tm), SecureRandom()) }.socketFactory
    }

    /** System trust store, used by the SNI scanner to report whether a certificate is really trusted. */
    val defaultTm: X509TrustManager by lazy {
        val f = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
        f.init(null as KeyStore?)
        f.trustManagers.first { it is X509TrustManager } as X509TrustManager
    }

    fun connect(host: String, port: Int, timeout: Int): Socket {
        val s = Socket()
        try {
            s.tcpNoDelay = true
            s.soTimeout = timeout
            s.connect(InetSocketAddress(host, port), timeout)
        } catch (e: Exception) {
            s.closeQuietly(); throw e
        }
        return s
    }

    /** Wraps an open socket in TLS with the given SNI (none if blank or an IP). */
    fun tls(sock: Socket, sni: String?, port: Int, timeout: Int): SSLSocket {
        val name = sni?.trim().orEmpty()
        val host = name.ifEmpty { sock.inetAddress.hostAddress ?: "" }
        val ssl = insecureFactory.createSocket(sock, host, port, true) as SSLSocket
        ssl.soTimeout = timeout
        if (name.isNotEmpty() && !Targets.isIpLiteral(name)) {
            try {
                val p = ssl.sslParameters
                p.serverNames = listOf(SNIHostName(name))
                ssl.sslParameters = p
            } catch (e: Exception) { }
        }
        ssl.startHandshake()
        return ssl
    }

    fun send(
        sock: Socket, method: String, target: String, host: String,
        extra: Map<String, String> = emptyMap(), body: ByteArray? = null,
    ) {
        val sb = StringBuilder()
        sb.append("$method $target HTTP/1.1\r\nHost: $host\r\n")
        sb.append("User-Agent: Mozilla/5.0 (Linux; Android 14) ScanTools/1.0\r\n")
        if (extra.keys.none { it.equals("Accept", true) }) sb.append("Accept: */*\r\n")
        if (method != "CONNECT") sb.append("Connection: close\r\n")
        extra.forEach { (k, v) -> sb.append("$k: $v\r\n") }
        if (body != null) sb.append("Content-Length: ${body.size}\r\n")
        sb.append("\r\n")
        val out = sock.getOutputStream()
        out.write(sb.toString().toByteArray(Charsets.ISO_8859_1))
        if (body != null) out.write(body)
        out.flush()
    }

    fun request(
        sock: Socket, method: String, target: String, host: String,
        extra: Map<String, String> = emptyMap(), body: ByteArray? = null, limit: Int = 64 * 1024,
    ): HttpResp {
        send(sock, method, target, host, extra, body)
        return readResponse(sock.getInputStream(), limit, headersOnly = false)
    }

    fun readResponse(input: InputStream, limit: Int, headersOnly: Boolean): HttpResp {
        val buf = ByteArrayOutputStream()
        val tmp = ByteArray(8192)
        var headerEnd = -1
        var contentLength = -1
        try {
            while (buf.size() < limit) {
                val n = input.read(tmp)
                if (n < 0) break
                buf.write(tmp, 0, n)
                if (headerEnd < 0) {
                    headerEnd = crlf2(buf.toByteArray())
                    if (headerEnd >= 0) {
                        if (headersOnly) break
                        val head = String(buf.toByteArray(), 0, headerEnd, Charsets.ISO_8859_1)
                        contentLength = head.lineSequence()
                            .firstOrNull { it.startsWith("content-length:", true) }
                            ?.substringAfter(':')?.trim()?.toIntOrNull() ?: -1
                        val code = head.lineSequence().first().split(' ').getOrNull(1)?.toIntOrNull()
                        if (code == 204 || code == 304) contentLength = 0
                    }
                }
                if (headerEnd >= 0 && contentLength >= 0 && buf.size() >= headerEnd + 4 + contentLength) break
            }
        } catch (e: SocketTimeoutException) {
            if (headerEnd < 0) throw e
        }
        val all = buf.toByteArray()
        val he = crlf2(all)
        if (he < 0) throw IOException(if (all.isEmpty()) "empty response" else "not HTTP")
        val head = String(all, 0, he, Charsets.ISO_8859_1)
        val statusLine = head.lineSequence().first()
        val status = statusLine.split(' ').getOrNull(1)?.toIntOrNull()
            ?: throw IOException("bad status line: ${statusLine.take(40)}")
        var body = all.copyOfRange(he + 4, all.size)
        if (head.contains("transfer-encoding: chunked", ignoreCase = true)) body = dechunk(body)
        return HttpResp(status, head, body)
    }

    private fun crlf2(b: ByteArray): Int {
        for (i in 0..b.size - 4) {
            if (b[i] == 13.toByte() && b[i + 1] == 10.toByte() && b[i + 2] == 13.toByte() && b[i + 3] == 10.toByte()) return i
        }
        return -1
    }

    private fun dechunk(b: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        var i = 0
        while (i < b.size) {
            var j = i
            while (j + 1 < b.size && !(b[j] == 13.toByte() && b[j + 1] == 10.toByte())) j++
            if (j + 1 >= b.size) break
            val len = String(b, i, j - i, Charsets.ISO_8859_1).substringBefore(';').trim().toIntOrNull(16) ?: break
            if (len == 0) break
            val start = j + 2
            val end = minOf(start + len, b.size)
            out.write(b, start, end - start)
            i = end + 2
        }
        return out.toByteArray()
    }

    fun <T> withSocket(host: String, port: Int, timeout: Int, tls: Boolean, sni: String?, block: (Socket) -> T): T {
        val raw = connect(host, port, timeout)
        var s: Socket = raw
        try {
            if (tls) s = tls(raw, sni, port, timeout)
            return block(s)
        } finally {
            s.closeQuietly(); raw.closeQuietly()
        }
    }
}
