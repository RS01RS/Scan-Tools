plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Version = GitHub Actions run number, like VPN Scan: "1.N (build N)"; the in-app updater compares N.
val runNo = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()

android {
    namespace = "com.scantools.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.scantools.app"
        minSdk = 26
        targetSdk = 34
        versionCode = runNo
        versionName = "1.$runNo"
    }

    // Fixed key (same as VPN Scan): new versions install over the old one without losing data.
    signingConfigs {
        create("rs") {
            storeFile = file("rs-key.jks")
            storePassword = "rsproxy"
            keyAlias = "rs"
            keyPassword = "rsproxy"
        }
    }

    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("rs") }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("rs")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}
