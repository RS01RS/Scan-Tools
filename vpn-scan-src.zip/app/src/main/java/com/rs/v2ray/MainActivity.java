package com.rs.v2ray;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URLEncoder;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

/** VPN Scan — جمع‌آوری کانفیگ‌های V2Ray و تست واقعی آن‌ها با هستهٔ Xray. */
public class MainActivity extends Activity {

    private WebView web;
    private final ExecutorService pool = Executors.newFixedThreadPool(48);
    private final Handler main = new Handler(Looper.getMainLooper());
    /** زبان پیام‌های اپ؛ صفحه با RSNative.setLang آن را عوض می‌کند. */
    private volatile boolean english = false;

    private String tr(String fa, String en) { return english ? en : fa; }

    private static final String V2RAYNG = "com.v2ray.ang";
    private static final String V2BOX = "dev.hexasoftware.v2box";
    private static final String HIDDIFY = "app.hiddify.com";
    private static final String NPV = "com.napsternetlabs.napsternetv";

    private void copyText(String text) {
        main.post(() -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("VPN Scan", text));
        });
    }

    // ---------- V2Ray: تست واقعی کانفیگ با هستهٔ Xray (libv2ray، همان هستهٔ v2rayNG) ----------
    private final ExecutorService tcpPool = Executors.newFixedThreadPool(64);
    // بدون سقف: هر تست در نخ خودش؛ تعداد تست هم‌زمان را صفحه کنترل می‌کند (صف شدن = timeout کاذب)
    private final ExecutorService corePool = Executors.newCachedThreadPool();
    private volatile int coreState = 0;          // 0 = آماده‌نشده، 1 = آماده، -1 = هسته نیست
    private volatile String coreError = "";

    private synchronized boolean ensureCore() {
        if (coreState != 0) return coreState == 1;
        try {
            libv2ray.Libv2ray.initCoreEnv(getFilesDir().getAbsolutePath(), "");
            coreState = 1;
        } catch (Throwable t) {
            coreState = -1;
            coreError = String.valueOf(t);
        }
        return coreState == 1;
    }

    /** IP دامنه با DNS خود گوشی (هستهٔ Go روی اندروید DNS گوشی را نمی‌بیند)، یا "" */
    private static String resolve(String host) {
        try { return InetAddress.getByName(host).getHostAddress(); } catch (Exception e) { return ""; }
    }

    /** {"ms": زمان اتصال TCP یا -1, "ip": آدرس} */
    private static String tcpPing(String host, int port, int timeoutMs) {
        String ip = resolve(host);
        long ms = -1;
        if (!ip.isEmpty()) {
            long t0 = System.nanoTime();
            try (Socket s = new Socket()) {
                s.connect(new InetSocketAddress(InetAddress.getByName(ip), port), timeoutMs);
                ms = Math.max(1, (System.nanoTime() - t0) / 1_000_000);
            } catch (Exception ignored) { }
        }
        return "{\"ms\":" + ms + ",\"ip\":" + JSONObject.quote(ip) + "}";
    }

    /**
     * آیا این IP کلودفلر روی اینترنت فعلی «تمیز» است؟
     * اتصال TLS با SNI کلودفلر و خواندن /cdn-cgi/trace؛ زمان به میلی‌ثانیه یا -1.
     */
    private static long cfProbe(String ip, int timeoutMs) {
        final String host = "speed.cloudflare.com";
        long t0 = System.nanoTime();
        try (Socket raw = new Socket()) {
            raw.connect(new InetSocketAddress(InetAddress.getByName(ip), 443), timeoutMs);
            raw.setSoTimeout(timeoutMs);
            SSLSocketFactory f = (SSLSocketFactory) SSLSocketFactory.getDefault();
            try (SSLSocket s = (SSLSocket) f.createSocket(raw, host, 443, true)) {
                s.startHandshake();
                OutputStream o = s.getOutputStream();
                o.write(("GET /cdn-cgi/trace HTTP/1.1\r\nHost: " + host + "\r\nUser-Agent: Mozilla/5.0\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.US_ASCII));
                o.flush();
                byte[] b = new byte[4096];
                int n = s.getInputStream().read(b);
                String r = n > 0 ? new String(b, 0, n, StandardCharsets.US_ASCII) : "";
                if (r.startsWith("HTTP/1.1 200") || r.contains("fl=")) return Math.max(1, (System.nanoTime() - t0) / 1_000_000);
            }
        } catch (Exception ignored) { }
        return -1;
    }

    /** تأخیر واقعی از داخل کانفیگ (مثل Real delay در v2rayNG) */
    private String coreTest(String configJson, String url, int timeoutMs) {
        JSONObject r = new JSONObject();
        try {
            if (!ensureCore()) { r.put("ok", false); r.put("err", "core: " + coreError); r.put("noCore", true); return r.toString(); }
            // خود هسته برای هر تلاش ۱۲ ثانیه مهلت دارد؛ این‌جا صبر می‌کنیم تا جواب واقعی بیاید
            long t0 = System.currentTimeMillis();
            long ms;
            try {
                ms = libv2ray.Libv2ray.measureOutboundDelay(configJson, url);
            } catch (Exception e) {
                r.put("ok", false); r.put("err", String.valueOf(e.getMessage())); return r.toString();
            }
            if (System.currentTimeMillis() - t0 > timeoutMs + 15000) { r.put("ok", false); r.put("err", "timeout"); return r.toString(); }
            if (ms > 0) { r.put("ok", true); r.put("ms", ms); }
            else { r.put("ok", false); r.put("err", "no response"); }
        } catch (Throwable t) {
            try { r.put("ok", false); r.put("err", String.valueOf(t)); } catch (Exception ignored) { }
        }
        return r.toString();
    }

    // ---------- دو هستهٔ جدا: Xray 25 (هستهٔ NPV Tunnel) و sing-box (هستهٔ Hiddify) ----------
    // هر تست = یک پردازهٔ کوچک با یک ورودی HTTP روی 127.0.0.1؛ درخواست از داخل آن به سرور می‌رود.
    private File coreBin(String core) {
        String name = "x25".equals(core) ? "libxray25.so" : "sb".equals(core) ? "libsingbox.so" : null;
        if (name == null) return null;
        File f = new File(getApplicationInfo().nativeLibraryDir, name);
        return f.exists() ? f : null;
    }

    private static int freePort() {
        try (java.net.ServerSocket s = new java.net.ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"))) { return s.getLocalPort(); }
        catch (Exception e) { return 20000 + (int) (Math.random() * 30000); }
    }

    /** یک درخواست از راه پراکسی محلی؛ زمان (ms) یا پیام خطا */
    private static Object proxGet(int port, String url, int timeoutMs) {
        HttpURLConnection c = null;
        try {
            java.net.Proxy px = new java.net.Proxy(java.net.Proxy.Type.HTTP, new InetSocketAddress("127.0.0.1", port));
            long t0 = System.nanoTime();
            c = (HttpURLConnection) new URL(url).openConnection(px);
            c.setConnectTimeout(timeoutMs); c.setReadTimeout(timeoutMs);
            c.setUseCaches(false); c.setInstanceFollowRedirects(false);
            c.setRequestProperty("Connection", "close");
            c.setRequestProperty("User-Agent", "Mozilla/5.0");
            int code = c.getResponseCode();
            try (InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream()) { if (in != null) { byte[] b = new byte[512]; while (in.read(b) > 0) { } } } catch (Exception ignored) { }
            long ms = (System.nanoTime() - t0) / 1000000;
            if (code >= 200 && code < 400) return Math.max(1L, ms);
            return "HTTP " + code;
        } catch (Exception e) {
            String m = e.getMessage(); return e.getClass().getSimpleName() + (m != null ? ": " + m : "");
        } finally { if (c != null) c.disconnect(); }
    }

    /** سرعت دانلود از راه پراکسی محلی (Mbps)؛ حداکثر maxBytes یا timeoutMs */
    private static double speedVia(int port, String url, long maxBytes, int timeoutMs) {
        HttpURLConnection c = null;
        try {
            java.net.Proxy px = new java.net.Proxy(java.net.Proxy.Type.HTTP, new InetSocketAddress("127.0.0.1", port));
            c = (HttpURLConnection) new URL(url).openConnection(px);
            c.setConnectTimeout(timeoutMs); c.setReadTimeout(timeoutMs); c.setUseCaches(false);
            c.setRequestProperty("User-Agent", "Mozilla/5.0");
            if (c.getResponseCode() != 200) return -1;
            long t0 = System.nanoTime(), n = 0, limit = timeoutMs * 1_000_000L;
            try (InputStream in = c.getInputStream()) {
                byte[] b = new byte[32768]; int k;
                while ((k = in.read(b)) > 0) { n += k; if (n >= maxBytes || System.nanoTime() - t0 > limit) break; }
            }
            double sec = (System.nanoTime() - t0) / 1e9;
            return n < 65536 || sec <= 0 ? -1 : Math.round(n * 8 / sec / 1e5) / 10.0;
        } catch (Exception e) { return -1; }
        finally { if (c != null) c.disconnect(); }
    }

    /** تست سرعت یک سرور با هستهٔ خودش (x26 داخل برنامه، x25 و sb پردازهٔ جدا) */
    private String speedTest(String core, String cfg, String url, int maxKb, int timeoutMs) {
        double mbps = -1;
        if ("x26".equals(core)) {
            libv2ray.CoreController ctl = null;
            try {
                if (!ensureCore()) return "-1";
                int port = freePort();
                ctl = libv2ray.Libv2ray.newCoreController(new libv2ray.CoreCallbackHandler() {
                    @Override public long startup() { return 0; }
                    @Override public long shutdown() { return 0; }
                    @Override public long onEmitStatus(long code, String msg) { return 0; }
                });
                ctl.startLoop(cfg.replace("\"__RSPORT__\"", String.valueOf(port)), 0);
                if (ctl.getIsRunning()) mbps = speedVia(port, url, maxKb * 1024L, timeoutMs);
            } catch (Throwable ignored) {
            } finally { try { if (ctl != null) ctl.stopLoop(); } catch (Throwable ignored) { } }
        } else {
            Run run = null;
            try {
                run = startCore(core, cfg);
                if (run.err == null) mbps = speedVia(run.port, url, maxKb * 1024L, timeoutMs);
            } catch (Throwable ignored) {
            } finally { stopCore(run); }
        }
        return String.valueOf(mbps);
    }

    /** یک هستهٔ جدا را با کانفیگ بالا می‌آورد؛ خروجی: پردازه + پورت، یا خطا (stage 0 / noCore) */
    private static final class Run { Process proc; File conf; int port; final StringBuilder out = new StringBuilder(); JSONObject err; }

    private Run startCore(String core, String cfg) throws Exception {
        Run run = new Run();
        File bin = coreBin(core);
        if (bin == null) {
            run.err = new JSONObject(); run.err.put("ok", false); run.err.put("noCore", true);
            run.err.put("err", tr("این هسته روی این گوشی نیست (فقط گوشی‌های ۶۴ بیتی)", "this core isn't available on this phone (64-bit phones only)"));
            return run;
        }
        run.port = freePort();
        run.conf = File.createTempFile("core_", ".json", getCacheDir());
        try (FileOutputStream o = new FileOutputStream(run.conf)) { o.write(cfg.replace("\"__RSPORT__\"", String.valueOf(run.port)).getBytes(StandardCharsets.UTF_8)); }
        ProcessBuilder pb = new ProcessBuilder(bin.getAbsolutePath(), "run", "-c", run.conf.getAbsolutePath());
        pb.directory(getCacheDir()); pb.redirectErrorStream(true);
        pb.environment().put("XRAY_LOCATION_ASSET", getCacheDir().getAbsolutePath());
        pb.environment().put("HOME", getCacheDir().getAbsolutePath());
        run.proc = pb.start();
        final Process pr = run.proc; final StringBuilder out = run.out;
        Thread rd = new Thread(() -> {
            try (InputStream in = pr.getInputStream()) {
                byte[] b = new byte[2048]; int n;
                while ((n = in.read(b)) > 0) synchronized (out) { if (out.length() < 4000) out.append(new String(b, 0, n, StandardCharsets.UTF_8)); }
            } catch (Exception ignored) { }
        });
        rd.setDaemon(true); rd.start();
        // صبر تا هسته بالا بیاید
        boolean up = false;
        long until = System.currentTimeMillis() + 5000;
        while (System.currentTimeMillis() < until) {
            if (!run.proc.isAlive()) break;
            try (Socket so = new Socket()) { so.connect(new InetSocketAddress("127.0.0.1", run.port), 200); up = true; break; } catch (Exception e) { Thread.sleep(60); }
        }
        if (!up) {
            Thread.sleep(100);
            String o; synchronized (out) { o = out.toString().replaceAll("\u001B\\[[0-9;]*m", "").trim(); }
            run.err = new JSONObject(); run.err.put("ok", false); run.err.put("stage", 0);
            run.err.put("err", o.isEmpty() ? "core didn't start" : o.substring(Math.max(0, o.length() - 300)));
        }
        return run;
    }

    private static void stopCore(Run run) {
        if (run == null) return;
        if (run.proc != null) run.proc.destroyForcibly();
        if (run.conf != null) run.conf.delete();
    }

    private String procTest(String core, String cfg, String url1, String url2, int timeoutMs) {
        JSONObject r = new JSONObject();
        Run run = null;
        try {
            run = startCore(core, cfg);
            if (run.err != null) return run.err.toString();
            Object a = proxGet(run.port, url1, timeoutMs);
            if (!(a instanceof Long)) { r.put("ok", false); r.put("stage", 1); r.put("err", String.valueOf(a)); return r.toString(); }
            Object b = proxGet(run.port, url2, timeoutMs);
            if (!(b instanceof Long)) { r.put("ok", false); r.put("stage", 2); r.put("err", String.valueOf(b)); return r.toString(); }
            r.put("ok", true); r.put("ms", ((Long) a + (Long) b) / 2);
        } catch (Throwable t) {
            try { r.put("ok", false); r.put("stage", 1); r.put("err", String.valueOf(t)); } catch (Exception ignored) { }
        } finally { stopCore(run); }
        return r.toString();
    }

    /** باز شدن چند سایت از داخل یک کانفیگ؛ خروجی: آرایهٔ زمان‌ها (ms) یا -1 */
    private String sitesTest(String core, String cfg, String urlsJson, int timeoutMs) {
        StringBuilder sb = new StringBuilder("[");
        Run run = null;
        try {
            org.json.JSONArray urls = new org.json.JSONArray(urlsJson);
            long[] ms = new long[urls.length()];
            java.util.Arrays.fill(ms, -1);
            if ("x26".equals(core)) {
                if (ensureCore()) {
                    java.util.List<Future<?>> fs = new java.util.ArrayList<>();
                    for (int i = 0; i < urls.length(); i++) {
                        final int k = i; final String u = urls.getString(i);
                        fs.add(corePool.submit(() -> { try { long v = libv2ray.Libv2ray.measureOutboundDelay(cfg, u); ms[k] = v > 0 ? v : -1; } catch (Throwable t) { ms[k] = -1; } }));
                    }
                    for (Future<?> f : fs) { try { f.get(30, TimeUnit.SECONDS); } catch (Exception ignored) { } }
                }
            } else {
                run = startCore(core, cfg);
                if (run.err == null) {
                    for (int i = 0; i < urls.length(); i++) {
                        Object v = proxGet(run.port, urls.getString(i), timeoutMs);
                        ms[i] = v instanceof Long ? (Long) v : -1;
                    }
                }
            }
            for (int i = 0; i < ms.length; i++) sb.append(i > 0 ? "," : "").append(ms[i]);
        } catch (Throwable ignored) {
        } finally { stopCore(run); }
        return sb.append("]").toString();
    }

    // ---------- کشور سرور از روی IP (بانک داخلی؛ روی نت ملی هم کار می‌کند) ----------
    private int[] geoStart; private byte[] geoCc;
    private synchronized boolean loadGeo() {
        if (geoStart != null) return true;
        try (java.io.DataInputStream in = new java.io.DataInputStream(new java.io.BufferedInputStream(getAssets().open("geo4.bin")))) {
            int n = in.readInt();
            int[] st = new int[n]; for (int i = 0; i < n; i++) st[i] = in.readInt();
            byte[] cc = new byte[2 * n]; in.readFully(cc);
            geoCc = cc; geoStart = st; return true;
        } catch (Exception e) { return false; }
    }
    /** "DE" · "~~" = CDN · "--" = نامعلوم */
    private String geo(String ip) {
        try {
            String[] p = ip.trim().split("\\.");
            if (p.length != 4 || !loadGeo()) return "";
            long v = 0; for (String x : p) { int b = Integer.parseInt(x); if (b < 0 || b > 255) return ""; v = (v << 8) | b; }
            int lo = 0, hi = geoStart.length - 1, ans = 0;
            while (lo <= hi) { int m = (lo + hi) >>> 1; if ((geoStart[m] & 0xFFFFFFFFL) <= v) { ans = m; lo = m + 1; } else hi = m - 1; }
            return new String(geoCc, 2 * ans, 2, StandardCharsets.US_ASCII);
        } catch (Exception e) { return ""; }
    }

    // ---------- لینک ساب داخلی: http://127.0.0.1:PORT/ng | /hid | /npv ----------
    private final java.util.concurrent.ConcurrentHashMap<String, String> subs = new java.util.concurrent.ConcurrentHashMap<>();
    private volatile java.net.ServerSocket subServer;
    private volatile int subPortNo = 0;
    private synchronized int startSub() {
        if (subServer != null && !subServer.isClosed()) return subPortNo;
        for (int port = 18920; port < 18930; port++) {
            try {
                java.net.ServerSocket ss = new java.net.ServerSocket(port, 16, InetAddress.getByName("127.0.0.1"));
                subServer = ss; subPortNo = port;
                Thread t = new Thread(() -> {
                    while (!ss.isClosed()) {
                        try { Socket c = ss.accept(); pool.execute(() -> serveSub(c)); } catch (Exception e) { if (ss.isClosed()) break; }
                    }
                });
                t.setDaemon(true); t.start();
                return port;
            } catch (Exception ignored) { }
        }
        return 0;
    }
    private void serveSub(Socket c) {
        try (Socket so = c) {
            so.setSoTimeout(5000);
            java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(so.getInputStream(), StandardCharsets.UTF_8));
            String line = br.readLine(); if (line == null) return;
            String path = line.split(" ").length > 1 ? line.split(" ")[1] : "/";
            while ((line = br.readLine()) != null && !line.isEmpty()) { }
            String key = path.replaceAll("^/+", "").replaceAll("[?#].*$", "");
            String body = subs.get(key);
            int code = body == null ? 404 : 200;
            if (body == null) body = "not found";
            byte[] data = body.getBytes(StandardCharsets.UTF_8);
            String title = android.util.Base64.encodeToString("VPN Scan · R.S".getBytes(StandardCharsets.UTF_8), android.util.Base64.NO_WRAP);
            String head = "HTTP/1.1 " + code + (code == 200 ? " OK" : " Not Found") + "\r\n"
                + "Content-Type: text/plain; charset=utf-8\r\n"
                + "Content-Length: " + data.length + "\r\n"
                + "profile-title: base64:" + title + "\r\n"
                + "profile-update-interval: 1\r\n"
                + "Cache-Control: no-store\r\n"
                + "Connection: close\r\n\r\n";
            OutputStream o = so.getOutputStream();
            o.write(head.getBytes(StandardCharsets.US_ASCII)); o.write(data); o.flush();
        } catch (Exception ignored) { }
    }

    // ---------- تم: رنگ نوار وضعیت و ناوبری ----------
    private void applyBars(boolean light) {
        int bg = light ? 0xFFEAF4FF : 0xFF06122B;
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        android.view.View d = getWindow().getDecorView();
        int f = d.getSystemUiVisibility();
        int m = android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        d.setSystemUiVisibility(light ? (f | m) : (f & ~m));
        if (web != null) web.setBackgroundColor(bg);
    }
    private boolean sysDark() {
        return (getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES;
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration c) {
        super.onConfigurationChanged(c);
        if (web != null) web.evaluateJavascript("window.RSOnSysTheme && window.RSOnSysTheme(" + sysDark() + ")", null);
    }

    private volatile String coreVers = null;
    private String coreVersions() {
        if (coreVers != null) return coreVers;
        JSONObject v = new JSONObject();
        try {
            if (ensureCore()) { try { v.put("x26", libv2ray.Libv2ray.checkVersionX().replaceAll("(?is).*?Xray[^0-9]*([0-9][0-9.]*).*", "$1")); } catch (Throwable t) { v.put("x26", "?"); } }
            if (coreBin("x25") != null) v.put("x25", BuildConfig.X25_VER);
            if (coreBin("sb") != null) v.put("sb", BuildConfig.SB_VER);
        } catch (Exception ignored) { }
        coreVers = v.toString();
        return coreVers;
    }

    // ---------- VPN: اجازهٔ اندروید، شروع سرویس، خبر دادن وضعیت به صفحه ----------
    private static final int VPN_REQ = 43;
    private String pendingCfg, pendingName, pendingCore, pendingHelper;

    private void pushVpn() {
        final String js = "window.RSOnVpn && window.RSOnVpn(" + RsVpnService.stateJson() + ")";
        main.post(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    private void startVpnFlow(String cfg, String name, String core, String helperCfg) {
        pendingCfg = cfg; pendingName = name; pendingCore = core; pendingHelper = helperCfg;
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 78);
        Intent prep = android.net.VpnService.prepare(this);
        if (prep != null) {
            try { startActivityForResult(prep, VPN_REQ); }
            catch (Exception e) { RsVpnService.state = "error"; RsVpnService.err = "VPN not supported"; pushVpn(); }
        } else launchVpn();
    }

    private void launchVpn() {
        if (pendingCfg == null) return;
        Intent i = new Intent(this, RsVpnService.class).setAction(RsVpnService.ACT_START)
            .putExtra("cfg", pendingCfg).putExtra("name", pendingName == null ? "" : pendingName)
            .putExtra("helperCore", pendingCore == null ? "x26" : pendingCore).putExtra("helperCfg", pendingHelper == null ? "" : pendingHelper);
        pendingCfg = null;
        try { startForegroundService(i); }
        catch (Exception e) { RsVpnService.state = "error"; RsVpnService.err = String.valueOf(e.getMessage()); pushVpn(); }
    }

    // ---------- بروزرسانی داخل برنامه (DownloadManager + نصب‌کنندهٔ اندروید) ----------
    private DownloadManager dm;
    private long updId = -1;
    private boolean installPending = false;
    private Runnable poller;

    private void updEvent(long done, long total, String st) {
        final String js = "window.RSUpdProgress && window.RSUpdProgress(" + done + "," + total + "," + JSONObject.quote(st) + ")";
        main.post(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    private void startUpdate(String url, String name) {
        try {
            dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            if (updId != -1) dm.remove(updId);
            String file = name != null && name.toLowerCase().endsWith(".apk") ? name.replaceAll("[^A-Za-z0-9._-]", "_") : "vpn-scan-update.apk";
            File old = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), file);
            if (old.exists()) old.delete();
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            r.setTitle("VPN Scan");
            r.setDescription(tr("دانلود نسخهٔ جدید", "Downloading update"));
            r.setMimeType("application/vnd.android.package-archive");
            r.addRequestHeader("User-Agent", "Mozilla/5.0 (Linux; Android 14) VPN-Scan/1.0");
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE);
            r.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, file);
            updId = dm.enqueue(r);
            installPending = false;
            pollUpdate();
        } catch (Exception e) {
            updId = -1;
            updEvent(0, 0, "failed");
        }
    }

    private void pollUpdate() {
        if (poller != null) main.removeCallbacks(poller);
        poller = new Runnable() {
            @Override
            public void run() {
                if (updId == -1 || dm == null) return;
                try (Cursor c = dm.query(new DownloadManager.Query().setFilterById(updId))) {
                    if (c == null || !c.moveToFirst()) { updId = -1; updEvent(0, 0, "failed"); return; }
                    int st = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                    long done = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
                    long total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
                    if (st == DownloadManager.STATUS_SUCCESSFUL) { updEvent(done, total, "done"); installUpdate(); return; }
                    if (st == DownloadManager.STATUS_FAILED) { dm.remove(updId); updId = -1; updEvent(done, total, "failed"); return; }
                    updEvent(done, total, st == DownloadManager.STATUS_PAUSED ? "paused" : st == DownloadManager.STATUS_PENDING ? "pending" : "running");
                } catch (Exception e) {
                    updEvent(0, 0, "failed");
                    return;
                }
                main.postDelayed(this, 400);
            }
        };
        main.post(poller);
    }

    private void installUpdate() {
        if (updId == -1 || dm == null) { updEvent(0, 0, "failed"); return; }
        if (!getPackageManager().canRequestPackageInstalls()) {
            installPending = true;     // بعد از برگشتن از تنظیمات، خودکار نصب می‌شود
            updEvent(0, 0, "permission");
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName())));
            } catch (Exception ignored) { }
            return;
        }
        installPending = false;
        try {
            Uri u = dm.getUriForDownloadedFile(updId);
            if (u == null) throw new Exception("no file");
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(u, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            updEvent(0, 0, "installFailed");
        }
    }

    private void cancelUpdate() {
        if (poller != null) main.removeCallbacks(poller);
        if (dm != null && updId != -1) dm.remove(updId);
        updId = -1;
        installPending = false;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (installPending && getPackageManager().canRequestPackageInstalls()) installUpdate();
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xFF06122B);
        getWindow().setNavigationBarColor(0xFF06122B);

        web = new WebView(this);
        web.setBackgroundColor(0xFF06122B);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMediaPlaybackRequiresUserGesture(true);

        // انتخاب فایل از گوشی برای <input type="file"> (لیست IP، فایل پروکسی/کانفیگ)
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    Intent i = params.createIntent();
                    i.setType("*/*");
                    startActivityForResult(i, FILE_REQ);
                } catch (Exception e) {
                    fileCb = null;
                    cb.onReceiveValue(null);
                    toast(tr("انتخاب فایل ممکن نشد", "Couldn't open the file picker"));
                    return false;
                }
                return true;
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("file".equals(u.getScheme())) return false;
                openExternal(u.toString());   // tg:// و لینک‌های بیرونی → تلگرام / مرورگر
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "RSNative");
        RsVpnService.listener = this::pushVpn;

        if (state != null) web.restoreState(state);
        else web.loadUrl("file:///android_asset/index.html");
    }

    private static final int FILE_REQ = 42;
    private ValueCallback<Uri[]> fileCb;

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == FILE_REQ && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
            return;
        }
        if (req == VPN_REQ) {
            if (res == RESULT_OK) launchVpn();
            else { pendingCfg = null; RsVpnService.state = "denied"; RsVpnService.err = ""; pushVpn(); }
            return;
        }
        super.onActivityResult(req, res, data);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (poller != null) main.removeCallbacks(poller);
        pool.shutdownNow();
        tcpPool.shutdownNow();
        corePool.shutdownNow();
        try { if (subServer != null) subServer.close(); } catch (Exception ignored) { }
        web.destroy();
        super.onDestroy();
    }

    private void openExternal(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            toast(url.startsWith("tg:") ? tr("تلگرام نصب نیست", "Telegram is not installed") : tr("برنامه‌ای برای باز کردن این لینک نیست", "No app can open this link"));
        }
    }

    private void toast(String msg) {
        main.post(() -> Toast.makeText(this, msg, Toast.LENGTH_SHORT).show());
    }

    private void callback(String id, String jsonLiteral) {
        final String js = "window.RSNativeCb && window.RSNativeCb(" + JSONObject.quote(id) + "," + jsonLiteral + ")";
        main.post(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    static String httpGet(String url, int timeoutMs) { return httpGet(url, timeoutMs, 4_000_000); }

    /** دریافت متن؛ maxBytes > 0 یعنی فقط همین مقدار از ابتدای فایل (Range) — برای کم کردن مصرف اینترنت */
    static String httpGet(String url, int timeoutMs, int maxBytes) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(Math.min(timeoutMs, 15000));
            c.setReadTimeout(timeoutMs);
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) VPN-Scan/1.0");
            if (maxBytes > 0 && maxBytes < 4_000_000) c.setRequestProperty("Range", "bytes=0-" + (maxBytes - 1));
            if (c.getResponseCode() / 100 != 2) return null;
            try (InputStream in = c.getInputStream()) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int n, total = 0;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                    total += n;
                    if (total >= (maxBytes > 0 ? maxBytes : 4_000_000)) break;
                }
                return new String(out.toByteArray(), StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    /** متدهایی که صفحهٔ R.S از طریق window.RSNative صدا می‌زند. */
    final class Bridge {

        @JavascriptInterface
        public void fetch(String id, String url, int timeoutMs) {
            pool.execute(() -> {
                String t = httpGet(url, Math.max(timeoutMs, 3000));
                callback(id, t == null ? "null" : JSONObject.quote(t));
            });
        }

        @JavascriptInterface
        public void fetchPart(String id, String url, int timeoutMs, int maxBytes) {
            pool.execute(() -> {
                String t = httpGet(url, Math.max(timeoutMs, 3000), maxBytes);
                callback(id, t == null ? "null" : JSONObject.quote(t));
            });
        }

        @JavascriptInterface
        public void copy(String text) {
            main.post(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("VPN Scan", text));
            });
        }

        @JavascriptInterface
        public String version() {
            try {
                android.content.pm.PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
                long code = Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode;
                return pi.versionName + " (build " + code + ")";
            } catch (Exception e) {
                return "";
            }
        }

        // ----- V2Ray -----
        @JavascriptInterface
        public void v2ping(String id, String host, int port, int timeoutMs) {
            tcpPool.execute(() -> callback(id, tcpPing(host, port, Math.max(timeoutMs, 1000))));
        }

        /** SHA-256 گواهی سرور (برای کانفیگ‌های insecure؛ هستهٔ Xray دیگر allowInsecure را قبول نمی‌کند) */
        @JavascriptInterface
        public void v2cert(String id, String address, int port, String serverName, boolean quic, int timeoutMs) {
            corePool.execute(() -> {
                String out;
                try {
                    if (!ensureCore()) { callback(id, "null"); return; }
                    JSONObject req = new JSONObject();
                    req.put("address", address); req.put("port", port); req.put("serverName", serverName); req.put("timeoutMs", (long) timeoutMs);
                    out = quic ? libv2ray.Libv2ray.fetchQuicCertSha256(req.toString()) : libv2ray.Libv2ray.fetchTlsCertSha256(req.toString());
                    if (out == null || out.isEmpty()) out = "null";
                } catch (Throwable t) {
                    out = "null";
                }
                callback(id, out);
            });
        }

        @JavascriptInterface
        public void cfprobe(String id, String ip, int timeoutMs) {
            tcpPool.execute(() -> callback(id, String.valueOf(cfProbe(ip, Math.max(timeoutMs, 1000)))));
        }

        @JavascriptInterface
        public void v2resolve(String id, String host) {
            tcpPool.execute(() -> callback(id, JSONObject.quote(resolve(host))));
        }

        @JavascriptInterface
        public void v2test(String id, String configJson, String url, int timeoutMs) {
            corePool.execute(() -> callback(id, coreTest(configJson, url, Math.max(timeoutMs, 3000))));
        }

        /** تست با هستهٔ جدا: core = "x25" | "sb" */
        @JavascriptInterface
        public void v2proc(String id, String core, String cfg, String url1, String url2, int timeoutMs) {
            corePool.execute(() -> callback(id, procTest(core, cfg, url1, url2, Math.max(timeoutMs, 3000))));
        }

        @JavascriptInterface
        public void v2sites(String id, String core, String cfg, String urlsJson, int timeoutMs) {
            corePool.execute(() -> callback(id, sitesTest(core, cfg, urlsJson, Math.max(timeoutMs, 3000))));
        }

        @JavascriptInterface
        public String v2geo(String ip) { return geo(ip); }

        @JavascriptInterface
        public void subSet(String key, String body) { if (key != null) { if (body == null || body.isEmpty()) subs.remove(key); else subs.put(key, body); } }

        @JavascriptInterface
        public int subPort() { return startSub(); }

        @JavascriptInterface
        public void setTheme(boolean light) { main.post(() -> applyBars(light)); }

        @JavascriptInterface
        public boolean sysDark() { return MainActivity.this.sysDark(); }

        // ---------- VPN داخل برنامه ----------
        @JavascriptInterface
        public void vpnStart(String cfg, String name) { main.post(() -> startVpnFlow(cfg, name, "x26", "")); }

        /** core = x26 | x25 | sb ؛ برای x25 و sb هستهٔ کمکی پشت TUN اجرا می‌شود */
        @JavascriptInterface
        public void vpnStartEx(String core, String cfg, String helperCfg, String name) { main.post(() -> startVpnFlow(cfg, name, core, helperCfg)); }

        @JavascriptInterface
        public void vpnStop() {
            main.post(() -> {
                if (RsVpnService.self == null) { RsVpnService.state = "off"; pushVpn(); return; }
                try { startService(new Intent(MainActivity.this, RsVpnService.class).setAction(RsVpnService.ACT_STOP)); } catch (Exception e) { pushVpn(); }
            });
        }

        @JavascriptInterface
        public String vpnState() { return RsVpnService.stateJson(); }

        @JavascriptInterface
        public void v2speed(String id, String core, String cfg, String url, int maxKb, int timeoutMs) {
            corePool.execute(() -> callback(id, speedTest(core, cfg, url, Math.max(maxKb, 256), Math.max(timeoutMs, 4000))));
        }

        @JavascriptInterface
        public void vpnInfo(String id) {
            corePool.execute(() -> { RsVpnService s = RsVpnService.self; callback(id, s == null ? "null" : s.info()); });
        }

        @JavascriptInterface
        public void vpnPing(String id) {
            corePool.execute(() -> { RsVpnService s = RsVpnService.self; callback(id, String.valueOf(s == null ? -1 : s.delay())); });
        }

        @JavascriptInterface
        public void v2cores(String id) {
            corePool.execute(() -> callback(id, coreVersions()));
        }

        @JavascriptInterface
        public String v2core() {
            if (!ensureCore()) return "";
            try { return libv2ray.Libv2ray.checkVersionX(); } catch (Throwable t) { return "Xray"; }
        }

        /**
         * فرستادن کانفیگ‌ها به برنامهٔ VPN.
         * v2rayNG: مستقیم وارد می‌شوند (مثل «Import from clipboard»).
         * V2Box: ورود مستقیم ندارد؛ لینک‌ها کپی می‌شوند و V2Box باز می‌شود.
         * خروجی: "sent" | "copied" | "missing"
         */
        @JavascriptInterface
        public String v2import(String links, String target) {
            if ("box".equals(target) || "hid".equals(target) || "npv".equals(target)) {
                copyText(links);
                String pkg = "hid".equals(target) ? HIDDIFY : "npv".equals(target) ? NPV : V2BOX;
                Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
                if (i == null) return "missing";
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try { startActivity(i); return "copied"; } catch (Exception e) { return "missing"; }
            }
            try {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.setPackage(V2RAYNG);
                // v2rayNG متن را URL-decode می‌کند؛ رمزگذاری می‌کنیم تا + و % در کانفیگ‌ها خراب نشوند
                i.putExtra(Intent.EXTRA_TEXT, URLEncoder.encode(links, "UTF-8"));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                return "sent";
            } catch (Exception e) {
                return "missing";
            }
        }

        @JavascriptInterface
        public void startUpdate(String url, String name) { main.post(() -> MainActivity.this.startUpdate(url, name)); }

        @JavascriptInterface
        public void installUpdate() { main.post(MainActivity.this::installUpdate); }

        @JavascriptInterface
        public void cancelUpdate() { main.post(MainActivity.this::cancelUpdate); }

        /** پنجرهٔ اشتراک‌گذاری اندروید (تلگرام، پیام‌رسان‌ها، …) */
        @JavascriptInterface
        public void share(String text) {
            main.post(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_SUBJECT, "VPN Scan");
                    i.putExtra(Intent.EXTRA_TEXT, text);
                    Intent c = Intent.createChooser(i, tr("اشتراک‌گذاری", "Share"));
                    c.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(c);
                } catch (Exception e) {
                    toast(tr("اشتراک‌گذاری ممکن نشد", "Couldn't share"));
                }
            });
        }

        @JavascriptInterface
        public void setLang(String lang) { english = "en".equals(lang); RsVpnService.english = english; }

        @JavascriptInterface
        public void open(String url) { main.post(() -> openExternal(url)); }

        @JavascriptInterface
        public void save(String name, String text) {
            pool.execute(() -> {
                try {
                    byte[] data = text.getBytes(StandardCharsets.UTF_8);
                    if (Build.VERSION.SDK_INT >= 29) {
                        ContentResolver r = getContentResolver();
                        ContentValues v = new ContentValues();
                        v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                        v.put(MediaStore.MediaColumns.MIME_TYPE, name.endsWith(".csv") ? "text/csv" : name.endsWith(".html") ? "text/html" : "text/plain");
                        v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                        Uri uri = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                        if (uri == null) throw new Exception("no uri");
                        try (OutputStream o = r.openOutputStream(uri)) { o.write(data); }
                        toast(tr("ذخیره شد: ", "Saved: ") + "Download/" + name);
                    } else {
                        File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                        File f = new File(dir, name);
                        try (FileOutputStream o = new FileOutputStream(f)) { o.write(data); }
                        toast(tr("ذخیره شد: ", "Saved: ") + f.getAbsolutePath());
                    }
                } catch (Exception e) {
                    toast(tr("ذخیره نشد", "Couldn't save"));
                }
            });
        }
    }
}
